--
-- PostgreSQL database dump
--

\restrict YL5YZrdDHMRoZsYs1q0ce7Yx5K8wYuDJeR5RC7kZhWjRZuzvNQNPf8IJ81LZzTZ

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.whatsapp_integration_userinstance DROP CONSTRAINT whatsapp_integration_userinstance_user_id_78f9fea9_fk;
ALTER TABLE ONLY public.whatsapp_integration_mensagemmassa DROP CONSTRAINT whatsapp_integration_mensagemmassa_remetente_id_96d98cb7_fk;
ALTER TABLE ONLY public.whatsapp_integration_mensagemmassa DROP CONSTRAINT whatsapp_integration_mensagemmassa_plano_filtro_id_ccf4626a_fk;
ALTER TABLE ONLY public.whatsapp_integration_mensagemmassa_tags_filtro DROP CONSTRAINT whatsapp_integration_mensagemmassa_id_1c762193_fk_whatsapp_;
ALTER TABLE ONLY public.whatsapp_integration_mensagemmassa_tags_filtro DROP CONSTRAINT whatsapp_integration_mens_tag_id_06189e57_fk;
ALTER TABLE ONLY public.whatsapp_integration_historicoenviomassa DROP CONSTRAINT whatsapp_integration_historicoenviomassa_cliente_id_605c6443_fk;
ALTER TABLE ONLY public.historico_mensagem_automatica DROP CONSTRAINT historico_mensagem_automatica_cliente_id_d712a266_fk;
ALTER TABLE ONLY public.historico_mensagem_automatica DROP CONSTRAINT historico_mensagem_automa_mensagem_configurada_id_1f219f0f_fk;
ALTER TABLE ONLY public.whatsapp_integration_historicoenviomassa DROP CONSTRAINT historico_envio_mass_mensagem_massa_id_96e6689d_fk_mensagem_;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_user_id_c564eba6_fk;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co;
ALTER TABLE ONLY public.clientes_tag DROP CONSTRAINT clientes_tag_usuario_id_e422545e_fk_clientes_customuser_id;
ALTER TABLE ONLY public.clientes_servico DROP CONSTRAINT clientes_servico_revenda_id_b768b128_fk;
ALTER TABLE ONLY public.clientes_relatoriofinanceiro DROP CONSTRAINT clientes_relatoriofinanceiro_cliente_id_039114bb_fk;
ALTER TABLE ONLY public.clientes_movimentacaocaixa DROP CONSTRAINT clientes_movimentacaocaixa_usuario_id_51e501f6_fk;
ALTER TABLE ONLY public.clientes_message DROP CONSTRAINT clientes_message_sender_id_79dae4af_fk;
ALTER TABLE ONLY public.clientes_message DROP CONSTRAINT clientes_message_receiver_id_f6201eaa_fk;
ALTER TABLE ONLY public.clientes_mensagemconfigurada DROP CONSTRAINT clientes_mensagemconfigurada_configuracao_id_a20c3332_fk;
ALTER TABLE ONLY public.clientes_mensagem DROP CONSTRAINT clientes_mensagem_usuario_id_66587a1f_fk;
ALTER TABLE ONLY public.clientes_logatividade DROP CONSTRAINT clientes_logatividade_usuario_id_a51688a4_fk;
ALTER TABLE ONLY public.clientes_jogofavorito DROP CONSTRAINT clientes_jogofavorit_cliente_id_25bdfaf7_fk_clientes_;
ALTER TABLE ONLY public.clientes_indicacao DROP CONSTRAINT clientes_indicacao_cliente_indicador_id_63b2b5e9_fk_clientes_;
ALTER TABLE ONLY public.clientes_indicacao DROP CONSTRAINT clientes_indicacao_cliente_indicado_id_0844b064_fk_clientes_;
ALTER TABLE ONLY public.clientes_historicomensagem DROP CONSTRAINT clientes_historicomensagem_mensagem_configurada_id_7bf3422a_fk;
ALTER TABLE ONLY public.clientes_historicomensagem DROP CONSTRAINT clientes_historicomensagem_cliente_id_4a13f5dc_fk;
ALTER TABLE ONLY public.clientes_historicojogo DROP CONSTRAINT clientes_historicojo_cliente_id_4d86bf4c_fk_clientes_;
ALTER TABLE ONLY public.clientes_financialscenario DROP CONSTRAINT clientes_financialscenario_user_id_ca0c0119_fk;
ALTER TABLE ONLY public.clientes_financialentry DROP CONSTRAINT clientes_financialentry_user_id_d2b7c7c0_fk;
ALTER TABLE ONLY public.clientes_financialentry DROP CONSTRAINT clientes_financialentry_scenario_id_5964271b_fk;
ALTER TABLE ONLY public.clientes_customuser_user_permissions DROP CONSTRAINT clientes_customuser_user_permissions_customuser_id_6dfd210e_fk;
ALTER TABLE ONLY public.clientes_customuser_tags DROP CONSTRAINT clientes_customuser_tags_tag_id_359e053b_fk;
ALTER TABLE ONLY public.clientes_customuser_tags DROP CONSTRAINT clientes_customuser_tags_customuser_id_b2867823_fk;
ALTER TABLE ONLY public.clientes_customuser DROP CONSTRAINT clientes_customuser_plano_id_01a55938_fk;
ALTER TABLE ONLY public.clientes_customuser_groups DROP CONSTRAINT clientes_customuser_groups_group_id_fe22daaf_fk_auth_group_id;
ALTER TABLE ONLY public.clientes_customuser_groups DROP CONSTRAINT clientes_customuser_groups_customuser_id_1e744e8e_fk;
ALTER TABLE ONLY public.clientes_customuser DROP CONSTRAINT clientes_customuser_dono_id_7efa077d_fk;
ALTER TABLE ONLY public.clientes_customuser_user_permissions DROP CONSTRAINT clientes_customuser__permission_id_3c9a40cb_fk_auth_perm;
ALTER TABLE ONLY public.clientes_configuracaomensagem DROP CONSTRAINT clientes_configuracaomensagem_usuario_id_daa44fe9_fk;
ALTER TABLE ONLY public.clientes_configuracao DROP CONSTRAINT clientes_configuracao_usuario_id_a7858294_fk;
ALTER TABLE ONLY public.clientes_configuracaoindicacao DROP CONSTRAINT clientes_configuraca_cliente_id_d18b9af8_fk_clientes_;
ALTER TABLE ONLY public.clientes_backupschedule DROP CONSTRAINT clientes_backupsched_usuario_id_73bb758e_fk_clientes_;
ALTER TABLE ONLY public.clientes_backuphistory DROP CONSTRAINT clientes_backuphisto_usuario_id_f50c39db_fk_clientes_;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm;
DROP INDEX public.whatsapp_integration_userinstance_user_id_78f9fea9;
DROP INDEX public.whatsapp_integration_userinstance_instance_name_df71448b_like;
DROP INDEX public.whatsapp_integration_mensagemmassa_tags_filtro_tag_id_06189e57;
DROP INDEX public.whatsapp_integration_mensagemmassa_remetente_id_96d98cb7;
DROP INDEX public.whatsapp_integration_mensagemmassa_plano_filtro_id_ccf4626a;
DROP INDEX public.whatsapp_integration_mensa_mensagemmassa_id_1c762193;
DROP INDEX public.whatsapp_integration_histo_mensagem_configurada_id_f16f436d;
DROP INDEX public.whatsapp_integration_histo_cliente_id_a3fd9d47;
DROP INDEX public.historico_envio_massa_mensagem_massa_id_96e6689d;
DROP INDEX public.historico_envio_massa_cliente_id_e16bb49f;
DROP INDEX public.django_site_domain_a2e37b91_like;
DROP INDEX public.django_session_session_key_c0390e0f_like;
DROP INDEX public.django_session_expire_date_a5c62663;
DROP INDEX public.django_admin_log_user_id_c564eba6;
DROP INDEX public.django_admin_log_content_type_id_c4bce8eb;
DROP INDEX public.clientes_tag_usuario_id_e422545e;
DROP INDEX public.clientes_servico_revenda_id_b768b128;
DROP INDEX public.clientes_relatoriofinanceiro_cliente_id_039114bb;
DROP INDEX public.clientes_movimentacaocaixa_usuario_id_51e501f6;
DROP INDEX public.clientes_message_sender_id_79dae4af;
DROP INDEX public.clientes_message_receiver_id_f6201eaa;
DROP INDEX public.clientes_mensagemconfigurada_configuracao_id_a20c3332;
DROP INDEX public.clientes_mensagem_destinatario_id_ba06f84e;
DROP INDEX public.clientes_logatividade_usuario_id_a51688a4;
DROP INDEX public.clientes_lo_usuario_cfebf8_idx;
DROP INDEX public.clientes_lo_tipo_ac_2c5f9d_idx;
DROP INDEX public.clientes_jogofavorito_cliente_id_25bdfaf7;
DROP INDEX public.clientes_indicacao_cliente_indicador_id_63b2b5e9;
DROP INDEX public.clientes_indicacao_cliente_indicado_id_0844b064;
DROP INDEX public.clientes_historicomensagem_mensagem_configurada_id_7bf3422a;
DROP INDEX public.clientes_historicomensagem_cliente_id_4a13f5dc;
DROP INDEX public.clientes_historicojogo_cliente_id_4d86bf4c;
DROP INDEX public.clientes_financialscenario_user_id_ca0c0119;
DROP INDEX public.clientes_financialentry_user_id_d2b7c7c0;
DROP INDEX public.clientes_financialentry_scenario_id_5964271b;
DROP INDEX public.clientes_customuser_username_d4ac33d6_like;
DROP INDEX public.clientes_customuser_user_permissions_permission_id_3c9a40cb;
DROP INDEX public.clientes_customuser_user_permissions_customuser_id_6dfd210e;
DROP INDEX public.clientes_customuser_tags_tag_id_359e053b;
DROP INDEX public.clientes_customuser_tags_customuser_id_b2867823;
DROP INDEX public.clientes_customuser_plano_id_01a55938;
DROP INDEX public.clientes_customuser_groups_group_id_fe22daaf;
DROP INDEX public.clientes_customuser_groups_customuser_id_1e744e8e;
DROP INDEX public.clientes_customuser_dono_id_7efa077d;
DROP INDEX public.clientes_configuracaoindicacao_cliente_id_d18b9af8;
DROP INDEX public.clientes_configuracao_usuario_id_a7858294;
DROP INDEX public.clientes_backupschedule_usuario_id_73bb758e;
DROP INDEX public.clientes_backuphistory_usuario_id_f50c39db;
DROP INDEX public.auth_permission_content_type_id_2f476e4b;
DROP INDEX public.auth_group_permissions_permission_id_84c5c92e;
DROP INDEX public.auth_group_permissions_group_id_b120cbf9;
DROP INDEX public.auth_group_name_a6ea08ec_like;
ALTER TABLE ONLY public.whatsapp_integration_userinstance DROP CONSTRAINT whatsapp_integration_userinstance_pkey;
ALTER TABLE ONLY public.whatsapp_integration_userinstance DROP CONSTRAINT whatsapp_integration_userinstance_instance_name_df71448b_uniq;
ALTER TABLE ONLY public.whatsapp_integration_mensagemmassa DROP CONSTRAINT whatsapp_integration_mensagemmassa_pkey;
ALTER TABLE ONLY public.whatsapp_integration_mensagemmassa_tags_filtro DROP CONSTRAINT whatsapp_integration_men_mensagemmassa_id_tag_id_8206ad43_uniq;
ALTER TABLE ONLY public.historico_mensagem_automatica DROP CONSTRAINT whatsapp_integration_historicomensagemautomatica_pkey;
ALTER TABLE ONLY public.whatsapp_integration_mensagemmassa_tags_filtro DROP CONSTRAINT mensagem_massa_tags_filtro_pkey;
ALTER TABLE ONLY public.whatsapp_integration_historicoenviomassa DROP CONSTRAINT historico_envio_massa_pkey;
ALTER TABLE ONLY public.django_site DROP CONSTRAINT django_site_pkey;
ALTER TABLE ONLY public.django_site DROP CONSTRAINT django_site_domain_a2e37b91_uniq;
ALTER TABLE ONLY public.django_session DROP CONSTRAINT django_session_pkey;
ALTER TABLE ONLY public.django_migrations DROP CONSTRAINT django_migrations_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_pkey;
ALTER TABLE ONLY public.clientes_verificationcode DROP CONSTRAINT clientes_verificationcode_pkey;
ALTER TABLE ONLY public.clientes_tutorial DROP CONSTRAINT clientes_tutorial_pkey;
ALTER TABLE ONLY public.clientes_tag DROP CONSTRAINT clientes_tag_pkey;
ALTER TABLE ONLY public.clientes_servico DROP CONSTRAINT clientes_servico_pkey;
ALTER TABLE ONLY public.clientes_relatoriofinanceiro DROP CONSTRAINT clientes_relatoriofinanceiro_pkey;
ALTER TABLE ONLY public.clientes_movimentacaocaixa DROP CONSTRAINT clientes_movimentacaocaixa_pkey;
ALTER TABLE ONLY public.clientes_message DROP CONSTRAINT clientes_message_pkey;
ALTER TABLE ONLY public.clientes_mensagemconfigurada DROP CONSTRAINT clientes_mensagemconfigurada_pkey;
ALTER TABLE ONLY public.clientes_mensagem DROP CONSTRAINT clientes_mensagem_pkey;
ALTER TABLE ONLY public.clientes_logatividade DROP CONSTRAINT clientes_logatividade_pkey;
ALTER TABLE ONLY public.clientes_jogofavorito DROP CONSTRAINT clientes_jogofavorito_pkey;
ALTER TABLE ONLY public.clientes_indicacao DROP CONSTRAINT clientes_indicacao_pkey;
ALTER TABLE ONLY public.clientes_indicacao DROP CONSTRAINT clientes_indicacao_cliente_indicador_id_cli_5faabd0e_uniq;
ALTER TABLE ONLY public.clientes_historicomensagem DROP CONSTRAINT clientes_historicomensagem_pkey;
ALTER TABLE ONLY public.clientes_historicojogo DROP CONSTRAINT clientes_historicojogo_pkey;
ALTER TABLE ONLY public.clientes_financialscenario DROP CONSTRAINT clientes_financialscenario_pkey;
ALTER TABLE ONLY public.clientes_financialentry DROP CONSTRAINT clientes_financialentry_pkey;
ALTER TABLE ONLY public.clientes_customuser DROP CONSTRAINT clientes_customuser_username_key;
ALTER TABLE ONLY public.clientes_customuser_user_permissions DROP CONSTRAINT clientes_customuser_user_permissions_pkey;
ALTER TABLE ONLY public.clientes_customuser_user_permissions DROP CONSTRAINT clientes_customuser_user_customuser_id_permission_0ef42de2_uniq;
ALTER TABLE ONLY public.clientes_customuser_tags DROP CONSTRAINT clientes_customuser_tags_pkey;
ALTER TABLE ONLY public.clientes_customuser_tags DROP CONSTRAINT clientes_customuser_tags_customuser_id_tag_id_4fadf8f8_uniq;
ALTER TABLE ONLY public.clientes_customuser DROP CONSTRAINT clientes_customuser_pkey;
ALTER TABLE ONLY public.clientes_customuser DROP CONSTRAINT clientes_customuser_link_acesso_key;
ALTER TABLE ONLY public.clientes_customuser_groups DROP CONSTRAINT clientes_customuser_groups_pkey;
ALTER TABLE ONLY public.clientes_customuser_groups DROP CONSTRAINT clientes_customuser_groups_customuser_id_group_id_1e46496d_uniq;
ALTER TABLE ONLY public.clientes_configuracaomensagem DROP CONSTRAINT clientes_configuracaomensagem_usuario_id_daa44fe9_uniq;
ALTER TABLE ONLY public.clientes_configuracaomensagem DROP CONSTRAINT clientes_configuracaomensagem_pkey;
ALTER TABLE ONLY public.clientes_configuracaoindicacao DROP CONSTRAINT clientes_configuracaoindicacao_pkey;
ALTER TABLE ONLY public.clientes_configuracao DROP CONSTRAINT clientes_configuracao_pkey;
ALTER TABLE ONLY public.clientes_backupschedule DROP CONSTRAINT clientes_backupschedule_pkey;
ALTER TABLE ONLY public.clientes_backuphistory DROP CONSTRAINT clientes_backuphistory_pkey;
ALTER TABLE ONLY public.clientes_atualizacao DROP CONSTRAINT clientes_atualizacao_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_name_key;
DROP TABLE public.whatsapp_integration_userinstance;
DROP TABLE public.whatsapp_integration_mensagemmassa;
DROP TABLE public.whatsapp_integration_mensagemmassa_tags_filtro;
DROP TABLE public.historico_mensagem_automatica;
DROP TABLE public.whatsapp_integration_historicoenviomassa;
DROP TABLE public.django_site;
DROP TABLE public.django_session;
DROP TABLE public.django_migrations;
DROP TABLE public.django_content_type;
DROP TABLE public.django_admin_log;
DROP TABLE public.clientes_verificationcode;
DROP TABLE public.clientes_tutorial;
DROP TABLE public.clientes_tag;
DROP TABLE public.clientes_servico;
DROP TABLE public.clientes_relatoriofinanceiro;
DROP TABLE public.clientes_movimentacaocaixa;
DROP TABLE public.clientes_message;
DROP TABLE public.clientes_mensagemconfigurada;
DROP TABLE public.clientes_mensagem;
DROP TABLE public.clientes_logatividade;
DROP TABLE public.clientes_jogofavorito;
DROP TABLE public.clientes_indicacao;
DROP TABLE public.clientes_historicomensagem;
DROP TABLE public.clientes_historicojogo;
DROP TABLE public.clientes_financialscenario;
DROP TABLE public.clientes_financialentry;
DROP TABLE public.clientes_customuser_user_permissions;
DROP TABLE public.clientes_customuser_tags;
DROP TABLE public.clientes_customuser_groups;
DROP TABLE public.clientes_customuser;
DROP TABLE public.clientes_configuracaomensagem;
DROP TABLE public.clientes_configuracaoindicacao;
DROP TABLE public.clientes_configuracao;
DROP TABLE public.clientes_backupschedule;
DROP TABLE public.clientes_backuphistory;
DROP TABLE public.clientes_atualizacao;
DROP TABLE public.auth_permission;
DROP TABLE public.auth_group_permissions;
DROP TABLE public.auth_group;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_atualizacao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_atualizacao (
    id bigint NOT NULL,
    titulo character varying(200),
    descricao text,
    data_criacao timestamp with time zone,
    tipo character varying(20),
    versao character varying(10),
    imagem character varying(100)
);


--
-- Name: clientes_atualizacao_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_atualizacao ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_atualizacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_backuphistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_backuphistory (
    id bigint NOT NULL,
    arquivo character varying(255) NOT NULL,
    tamanho bigint NOT NULL,
    status character varying(20) NOT NULL,
    erro text,
    data_criacao timestamp with time zone NOT NULL,
    usuario_id bigint NOT NULL,
    telegram_message_id character varying(100)
);


--
-- Name: clientes_backuphistory_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_backuphistory ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_backuphistory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_backupschedule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_backupschedule (
    id bigint NOT NULL,
    frequencia character varying(10) NOT NULL,
    manter_ultimos integer NOT NULL,
    ativo boolean NOT NULL,
    ultimo_backup timestamp with time zone,
    proximo_backup timestamp with time zone,
    data_criacao timestamp with time zone NOT NULL,
    usuario_id bigint NOT NULL
);


--
-- Name: clientes_backupschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_backupschedule ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_backupschedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_configuracao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_configuracao (
    id bigint NOT NULL,
    mercado_pago_access_token character varying(255),
    token_telegram character varying(255),
    chave_telegram character varying(255),
    numero_celular character varying(20),
    senha character varying(255),
    usuario_id bigint,
    email character varying(255)
);


--
-- Name: clientes_configuracao_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_configuracao ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_configuracao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_configuracaoindicacao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_configuracaoindicacao (
    id bigint NOT NULL,
    tipo_comissao character varying(20) NOT NULL,
    valor_por_indicacao numeric(10,2) NOT NULL,
    valor_por_renovacao numeric(10,2) NOT NULL,
    ativar_meta boolean NOT NULL,
    quantidade_meta integer NOT NULL,
    bonus_meta numeric(10,2) NOT NULL,
    validade_meses integer NOT NULL,
    ativo boolean NOT NULL,
    data_criacao timestamp with time zone NOT NULL,
    cliente_id bigint NOT NULL,
    data_atualizacao timestamp with time zone NOT NULL
);


--
-- Name: clientes_configuracaoindicacao_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_configuracaoindicacao ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_configuracaoindicacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_configuracaomensagem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_configuracaomensagem (
    id bigint NOT NULL,
    usuario_id bigint NOT NULL
);


--
-- Name: clientes_configuracaomensagem_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_configuracaomensagem ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_configuracaomensagem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_customuser; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_customuser (
    id bigint NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    tipo_usuario character varying(10) NOT NULL,
    data_vencimento date,
    valor_servico numeric(10,2),
    valor_a_pagar numeric(10,2),
    observacao text,
    whatsapp character varying(20),
    plano_id bigint,
    nome character varying(100),
    data_criacao timestamp with time zone NOT NULL,
    dono_id bigint,
    senha_leitura character varying(128),
    saldo numeric(10,2) NOT NULL,
    pix_code character varying(255),
    pix_code_base64 text,
    pix_code_created_at timestamp with time zone,
    link_acesso uuid,
    whatsapp_avatar_base64 text,
    whatsapp_avatar_error text,
    whatsapp_avatar_expires timestamp with time zone,
    whatsapp_avatar_status character varying(20) NOT NULL,
    whatsapp_avatar_updated timestamp with time zone,
    whatsapp_avatar_url character varying(500),
    cadastro_online boolean NOT NULL,
    data_cadastro timestamp with time zone NOT NULL
);


--
-- Name: clientes_customuser_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_customuser_groups (
    id integer NOT NULL,
    customuser_id bigint NOT NULL,
    group_id integer NOT NULL
);


--
-- Name: clientes_customuser_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_customuser_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_customuser_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_customuser_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_customuser ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_customuser_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_customuser_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_customuser_tags (
    id integer NOT NULL,
    customuser_id bigint NOT NULL,
    tag_id bigint NOT NULL
);


--
-- Name: clientes_customuser_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_customuser_tags ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_customuser_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_customuser_user_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_customuser_user_permissions (
    id integer NOT NULL,
    customuser_id bigint NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: clientes_customuser_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_customuser_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_customuser_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_financialentry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_financialentry (
    id bigint NOT NULL,
    description character varying(200) NOT NULL,
    amount numeric(12,2) NOT NULL,
    entry_type character varying(10) NOT NULL,
    category character varying(100) NOT NULL,
    entry_date date NOT NULL,
    created_at timestamp with time zone,
    include_in_balance boolean NOT NULL,
    scenario_id bigint NOT NULL,
    user_id bigint NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: clientes_financialentry_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_financialentry ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_financialentry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_financialscenario; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_financialscenario (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    is_default boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    user_id bigint NOT NULL
);


--
-- Name: clientes_financialscenario_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_financialscenario ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_financialscenario_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_historicojogo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_historicojogo (
    id bigint NOT NULL,
    time_casa character varying(100) NOT NULL,
    time_fora character varying(100) NOT NULL,
    campeonato character varying(150) NOT NULL,
    horario character varying(10) NOT NULL,
    data_acesso timestamp with time zone NOT NULL,
    cliente_id bigint NOT NULL
);


--
-- Name: clientes_historicojogo_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_historicojogo ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_historicojogo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_historicomensagem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_historicomensagem (
    id bigint NOT NULL,
    mensagem_final_enviada text,
    data_tentativa timestamp with time zone NOT NULL,
    status character varying(100),
    detalhes text,
    cliente_id bigint,
    mensagem_configurada_id bigint
);


--
-- Name: clientes_historicomensagem_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_historicomensagem ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_historicomensagem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_indicacao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_indicacao (
    id bigint NOT NULL,
    data_indicacao timestamp with time zone NOT NULL,
    observacao text,
    cliente_indicado_id bigint NOT NULL,
    cliente_indicador_id bigint NOT NULL
);


--
-- Name: clientes_indicacao_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_indicacao ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_indicacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_jogofavorito; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_jogofavorito (
    id bigint NOT NULL,
    jogo_id character varying(200) NOT NULL,
    time_casa character varying(100) NOT NULL,
    time_fora character varying(100) NOT NULL,
    campeonato character varying(150) NOT NULL,
    criado_em timestamp with time zone NOT NULL,
    cliente_id bigint NOT NULL
);


--
-- Name: clientes_jogofavorito_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_jogofavorito ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_jogofavorito_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_logatividade; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_logatividade (
    id bigint NOT NULL,
    tipo_acao character varying(50) NOT NULL,
    descricao text NOT NULL,
    modelo_afetado character varying(100),
    objeto_id character varying(50),
    dados_antes jsonb,
    dados_depois jsonb,
    ip_address inet,
    user_agent text,
    data_hora timestamp with time zone NOT NULL,
    duracao double precision,
    status character varying(20) NOT NULL,
    url_acessada character varying(200),
    metodo_http character varying(10),
    usuario_id bigint
);


--
-- Name: clientes_logatividade_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_logatividade ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_logatividade_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_mensagem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_mensagem (
    id bigint NOT NULL,
    conteudo text NOT NULL,
    data_envio timestamp with time zone NOT NULL,
    usuario_id bigint NOT NULL,
    numero character varying(15),
    status character varying(20) NOT NULL
);


--
-- Name: clientes_mensagem_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_mensagem ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_mensagem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_mensagemconfigurada; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_mensagemconfigurada (
    id bigint NOT NULL,
    criterio_dias integer NOT NULL,
    mensagem_texto text NOT NULL,
    horario_envio time without time zone NOT NULL,
    configuracao_id bigint NOT NULL
);


--
-- Name: clientes_mensagemconfigurada_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_mensagemconfigurada ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_mensagemconfigurada_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_message (
    id bigint NOT NULL,
    content text NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    is_read boolean NOT NULL,
    receiver_id bigint NOT NULL,
    sender_id bigint NOT NULL
);


--
-- Name: clientes_message_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_message ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_message_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_movimentacaocaixa; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_movimentacaocaixa (
    id bigint NOT NULL,
    tipo character varying(10) NOT NULL,
    valor numeric(10,2) NOT NULL,
    descricao character varying(200) NOT NULL,
    categoria character varying(20) NOT NULL,
    data timestamp with time zone NOT NULL,
    usuario_id bigint NOT NULL
);


--
-- Name: clientes_movimentacaocaixa_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_movimentacaocaixa ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_movimentacaocaixa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_relatoriofinanceiro; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_relatoriofinanceiro (
    id bigint NOT NULL,
    valor_pago numeric(10,2) NOT NULL,
    valor_servico numeric(10,2) NOT NULL,
    valor_liquido numeric(10,2) NOT NULL,
    servidor character varying(100),
    data_geracao timestamp with time zone NOT NULL,
    cliente_id bigint NOT NULL,
    is_manual boolean NOT NULL
);


--
-- Name: clientes_relatoriofinanceiro_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_relatoriofinanceiro ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_relatoriofinanceiro_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_servico; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_servico (
    id bigint NOT NULL,
    nome character varying(100) NOT NULL,
    valor numeric(10,2),
    cor character varying(7),
    observacao text,
    revenda_id bigint,
    custos numeric(10,2)
);


--
-- Name: clientes_servico_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_servico ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_servico_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_tag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_tag (
    id bigint NOT NULL,
    descricao text,
    nome character varying(100) NOT NULL,
    cor character varying(7) NOT NULL,
    data_criacao timestamp with time zone,
    usuario_id bigint
);


--
-- Name: clientes_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_tag ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_tutorial; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_tutorial (
    id bigint NOT NULL,
    titulo character varying(200) NOT NULL,
    descricao text,
    video_url character varying(2000),
    data_criacao timestamp with time zone NOT NULL
);


--
-- Name: clientes_tutorial_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_tutorial ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_tutorial_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: clientes_verificationcode; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes_verificationcode (
    id bigint NOT NULL,
    code character varying(6) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    is_used boolean NOT NULL,
    session_key character varying(40),
    code_type character varying(10) NOT NULL,
    whatsapp_number character varying(20)
);


--
-- Name: clientes_verificationcode_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.clientes_verificationcode ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.clientes_verificationcode_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id bigint NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.django_admin_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


--
-- Name: django_site; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.django_site ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: whatsapp_integration_historicoenviomassa; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.whatsapp_integration_historicoenviomassa (
    id bigint NOT NULL,
    status character varying(20) NOT NULL,
    data_envio timestamp with time zone NOT NULL,
    cliente_id bigint NOT NULL,
    mensagem_massa_id bigint NOT NULL,
    data_confirmacao timestamp with time zone,
    mensagem_erro text NOT NULL,
    message_id character varying(255) NOT NULL,
    whatsapp character varying(20) NOT NULL
);


--
-- Name: historico_envio_massa_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.whatsapp_integration_historicoenviomassa ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.historico_envio_massa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: historico_mensagem_automatica; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.historico_mensagem_automatica (
    id bigint NOT NULL,
    data_tentativa timestamp with time zone NOT NULL,
    status character varying(100),
    detalhes text,
    mensagem_final_enviada text,
    api_message_id character varying(100),
    data_envio timestamp with time zone,
    cliente_id bigint,
    mensagem_configurada_id bigint
);


--
-- Name: whatsapp_integration_mensagemmassa_tags_filtro; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.whatsapp_integration_mensagemmassa_tags_filtro (
    id integer NOT NULL,
    mensagemmassa_id bigint NOT NULL,
    tag_id bigint NOT NULL
);


--
-- Name: mensagem_massa_tags_filtro_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.whatsapp_integration_mensagemmassa_tags_filtro ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.mensagem_massa_tags_filtro_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: whatsapp_integration_historicomensagemautomatica_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.historico_mensagem_automatica ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.whatsapp_integration_historicomensagemautomatica_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: whatsapp_integration_mensagemmassa; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.whatsapp_integration_mensagemmassa (
    id bigint NOT NULL,
    mensagem text NOT NULL,
    data_agendamento timestamp with time zone,
    remetente_id bigint NOT NULL,
    agendada boolean NOT NULL,
    data_criacao timestamp with time zone NOT NULL,
    data_envio_fim timestamp with time zone,
    enviados_com_falha integer NOT NULL,
    enviados_com_sucesso integer NOT NULL,
    status character varying(20) NOT NULL,
    data_envio_inicio timestamp with time zone,
    dias_vencido_filtro integer,
    midia character varying(100),
    plano_filtro_id bigint,
    status_filtro character varying(20) NOT NULL,
    tipo_midia character varying(50) NOT NULL,
    total_destinatarios integer NOT NULL
);


--
-- Name: whatsapp_integration_mensagemmassa_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.whatsapp_integration_mensagemmassa ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.whatsapp_integration_mensagemmassa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: whatsapp_integration_userinstance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.whatsapp_integration_userinstance (
    id bigint NOT NULL,
    instance_name character varying(100) NOT NULL,
    status character varying(20) NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    last_check timestamp with time zone NOT NULL,
    owner_jid character varying(200),
    profile_name character varying(200),
    profile_pic_url text,
    instance_token character varying(100),
    is_active boolean NOT NULL,
    qr_code_data text,
    qr_generated_at timestamp with time zone,
    api_key character varying(255),
    base_url character varying(200) NOT NULL
);


--
-- Name: whatsapp_integration_userinstance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.whatsapp_integration_userinstance ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.whatsapp_integration_userinstance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add content type	4	add_contenttype
14	Can change content type	4	change_contenttype
15	Can delete content type	4	delete_contenttype
16	Can view content type	4	view_contenttype
17	Can add session	5	add_session
18	Can change session	5	change_session
19	Can delete session	5	delete_session
20	Can view session	5	view_session
21	Can add site	6	add_site
22	Can change site	6	change_site
23	Can delete site	6	delete_site
24	Can view site	6	view_site
25	Can add user	7	add_customuser
26	Can change user	7	change_customuser
27	Can delete user	7	delete_customuser
28	Can view user	7	view_customuser
29	Can add relatorio financeiro	8	add_relatoriofinanceiro
30	Can change relatorio financeiro	8	change_relatoriofinanceiro
31	Can delete relatorio financeiro	8	delete_relatoriofinanceiro
32	Can view relatorio financeiro	8	view_relatoriofinanceiro
33	Can add servico	9	add_servico
34	Can change servico	9	change_servico
35	Can delete servico	9	delete_servico
36	Can view servico	9	view_servico
37	Can add tag	10	add_tag
38	Can change tag	10	change_tag
39	Can delete tag	10	delete_tag
40	Can view tag	10	view_tag
41	Can add mensagem	11	add_mensagem
42	Can change mensagem	11	change_mensagem
43	Can delete mensagem	11	delete_mensagem
44	Can view mensagem	11	view_mensagem
45	Can add configuracao mensagem	12	add_configuracaomensagem
46	Can change configuracao mensagem	12	change_configuracaomensagem
47	Can delete configuracao mensagem	12	delete_configuracaomensagem
48	Can view configuracao mensagem	12	view_configuracaomensagem
49	Can add message	13	add_message
50	Can change message	13	change_message
51	Can delete message	13	delete_message
52	Can view message	13	view_message
53	Can add configuracao	14	add_configuracao
54	Can change configuracao	14	change_configuracao
55	Can delete configuracao	14	delete_configuracao
56	Can view configuracao	14	view_configuracao
57	Can add atualizacao	15	add_atualizacao
58	Can change atualizacao	15	change_atualizacao
59	Can delete atualizacao	15	delete_atualizacao
60	Can view atualizacao	15	view_atualizacao
61	Can add mensagem configurada	16	add_mensagemconfigurada
62	Can change mensagem configurada	16	change_mensagemconfigurada
63	Can delete mensagem configurada	16	delete_mensagemconfigurada
64	Can view mensagem configurada	16	view_mensagemconfigurada
65	Can add tutorial	17	add_tutorial
66	Can change tutorial	17	change_tutorial
67	Can delete tutorial	17	delete_tutorial
68	Can view tutorial	17	view_tutorial
69	Can add historico mensagem	18	add_historicomensagem
70	Can change historico mensagem	18	change_historicomensagem
71	Can delete historico mensagem	18	delete_historicomensagem
72	Can view historico mensagem	18	view_historicomensagem
73	Can add movimentacao caixa	19	add_movimentacaocaixa
74	Can change movimentacao caixa	19	change_movimentacaocaixa
75	Can delete movimentacao caixa	19	delete_movimentacaocaixa
76	Can view movimentacao caixa	19	view_movimentacaocaixa
77	Can add Log de Atividade	20	add_logatividade
78	Can change Log de Atividade	20	change_logatividade
79	Can delete Log de Atividade	20	delete_logatividade
80	Can view Log de Atividade	20	view_logatividade
81	Can add Instância WhatsApp	21	add_userinstance
82	Can change Instância WhatsApp	21	change_userinstance
83	Can delete Instância WhatsApp	21	delete_userinstance
84	Can view Instância WhatsApp	21	view_userinstance
85	Can add historico mensagem automatica	22	add_historicomensagemautomatica
86	Can change historico mensagem automatica	22	change_historicomensagemautomatica
87	Can delete historico mensagem automatica	22	delete_historicomensagemautomatica
88	Can view historico mensagem automatica	22	view_historicomensagemautomatica
89	Can add Mensagem em Massa	23	add_mensagemmassa
90	Can change Mensagem em Massa	23	change_mensagemmassa
91	Can delete Mensagem em Massa	23	delete_mensagemmassa
92	Can view Mensagem em Massa	23	view_mensagemmassa
93	Can add historico envio massa	24	add_historicoenviomassa
94	Can change historico envio massa	24	change_historicoenviomassa
95	Can delete historico envio massa	24	delete_historicoenviomassa
96	Can view historico envio massa	24	view_historicoenviomassa
97	Can add financial scenario	25	add_financialscenario
98	Can change financial scenario	25	change_financialscenario
99	Can delete financial scenario	25	delete_financialscenario
100	Can view financial scenario	25	view_financialscenario
101	Can add financial entry	26	add_financialentry
102	Can change financial entry	26	change_financialentry
103	Can delete financial entry	26	delete_financialentry
104	Can view financial entry	26	view_financialentry
105	Can add jogo favorito	27	add_jogofavorito
106	Can change jogo favorito	27	change_jogofavorito
107	Can delete jogo favorito	27	delete_jogofavorito
108	Can view jogo favorito	27	view_jogofavorito
109	Can add historico jogo	28	add_historicojogo
110	Can change historico jogo	28	change_historicojogo
111	Can delete historico jogo	28	delete_historicojogo
112	Can view historico jogo	28	view_historicojogo
113	Can add Indicação	29	add_indicacao
114	Can change Indicação	29	change_indicacao
115	Can delete Indicação	29	delete_indicacao
116	Can view Indicação	29	view_indicacao
117	Can add Configuração de Indicação	30	add_configuracaoindicacao
118	Can change Configuração de Indicação	30	change_configuracaoindicacao
119	Can delete Configuração de Indicação	30	delete_configuracaoindicacao
120	Can view Configuração de Indicação	30	view_configuracaoindicacao
121	Can add Código de Verificação	31	add_verificationcode
122	Can change Código de Verificação	31	change_verificationcode
123	Can delete Código de Verificação	31	delete_verificationcode
124	Can view Código de Verificação	31	view_verificationcode
125	Can add Histórico de Backup	32	add_backuphistory
126	Can change Histórico de Backup	32	change_backuphistory
127	Can delete Histórico de Backup	32	delete_backuphistory
128	Can view Histórico de Backup	32	view_backuphistory
129	Can add Agendamento de Backup	33	add_backupschedule
130	Can change Agendamento de Backup	33	change_backupschedule
131	Can delete Agendamento de Backup	33	delete_backupschedule
132	Can view Agendamento de Backup	33	view_backupschedule
\.


--
-- Data for Name: clientes_atualizacao; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_atualizacao (id, titulo, descricao, data_criacao, tipo, versao, imagem) FROM stdin;
\.


--
-- Data for Name: clientes_backuphistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_backuphistory (id, arquivo, tamanho, status, erro, data_criacao, usuario_id, telegram_message_id) FROM stdin;
6	backup_20260605_202357.sql	0	running	\N	2026-06-05 20:23:57.464625-03	3	\N
7	backup_20260606_115337.sql	0	running	\N	2026-06-06 11:53:37.143569-03	3	\N
\.


--
-- Data for Name: clientes_backupschedule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_backupschedule (id, frequencia, manter_ultimos, ativo, ultimo_backup, proximo_backup, data_criacao, usuario_id) FROM stdin;
1	1h	7	t	\N	2026-06-05 14:21:43.030524-03	2026-06-04 21:23:05.077643-03	3
\.


--
-- Data for Name: clientes_configuracao; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_configuracao (id, mercado_pago_access_token, token_telegram, chave_telegram, numero_celular, senha, usuario_id, email) FROM stdin;
3	\N	\N	\N	\N	\N	6	\N
2	\N	\N	\N	5564981688931	123456	\N	thyagolyma2015@hotmail.com
1	\N	1103334762:AAEvhYWE48KqL9uwCbB_KM-Zzk6R-IG3P40	505357397	64981688931	\N	3	thyagolyma2015@hotmail.com
\.


--
-- Data for Name: clientes_configuracaoindicacao; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_configuracaoindicacao (id, tipo_comissao, valor_por_indicacao, valor_por_renovacao, ativar_meta, quantidade_meta, bonus_meta, validade_meses, ativo, data_criacao, cliente_id, data_atualizacao) FROM stdin;
1	indicacao	5.00	0.00	f	3	0.00	1	t	2026-06-02 21:15:11.172098-03	5	2026-06-02 21:15:11.172098-03
3	indicacao	5.00	2.00	f	3	0.00	1	t	2026-06-02 21:45:38.754234-03	4	2026-06-02 21:45:38.755225-03
2	indicacao	0.00	0.00	t	2	23.00	1	t	2026-06-02 21:24:25.88263-03	8	2026-06-02 22:10:21.989409-03
\.


--
-- Data for Name: clientes_configuracaomensagem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_configuracaomensagem (id, usuario_id) FROM stdin;
1	6
2	3
\.


--
-- Data for Name: clientes_customuser; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_customuser (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, tipo_usuario, data_vencimento, valor_servico, valor_a_pagar, observacao, whatsapp, plano_id, nome, data_criacao, dono_id, senha_leitura, saldo, pix_code, pix_code_base64, pix_code_created_at, link_acesso, whatsapp_avatar_base64, whatsapp_avatar_error, whatsapp_avatar_expires, whatsapp_avatar_status, whatsapp_avatar_updated, whatsapp_avatar_url, cadastro_online, data_cadastro) FROM stdin;
8		2026-01-18 11:50:32.835774-03	f	fernando	fernando2		thyagolyma201s5@hotmail.com	f	f	2026-01-18 11:50:17.502927-03	cliente	2026-04-07	7.00	35.00		(55) 44998-6639	2	fernando2	2026-01-18 11:50:17.502927-03	3	pbkdf2_sha256$600000$VEqBssfejpEheP74kJGDtS$nEHWN8dFEKxDJsJAfhuVq35SdrdI24SrMmjYPbczhp4=	30.00	\N	\N	\N	6c29554b-6a77-4a14-873e-ff0f2bf5006b	\N	Foto não encontrada	\N	not_found	\N	\N	f	2026-06-04 20:07:23.990654-03
11		\N	f	dfhedxvg	amanda			f	t	2026-06-02 23:27:03.804765-03	cliente	2026-07-12	7.00	35.00		5564981688931	2	amanda	2026-06-02 23:27:03.804765-03	3	\N	0.00	\N	\N	\N	1a00d688-1ef9-43ed-b92f-af85fe3245f1	\N	\N	2026-06-11 19:35:30.920585-03	found	2026-06-04 19:35:30.920585-03	https://pps.whatsapp.net/v/t61.24694-24/604013595_1524881422075346_2735566125605828191_n.jpg?ccb=11-4&oh=01_Q5Aa4wGWcu50_oK_2JVjtv7amKBpu0xlhFIsmVnZkUoLftK5VA&oe=6A2F075B&_nc_sid=5e03e0&_nc_cat=106	f	2026-06-04 20:07:23.990654-03
5	ndjncdj	\N	f	raimundo				f	t	2026-01-10 23:05:43.25496-03	cliente	2026-07-03	6.00	30.00		+55 64 8454-527	1	Raimundo	2026-01-10 23:05:43.25496-03	3	\N	0.00	\N	\N	\N	ea0af3aa-a64e-4c2d-b4f1-9cd46c5b48dc	\N	Erro 404: {"status":404,"error":"Not Found","response":{"message":["The \\"jbhb\\" instance does not exist"]}}	\N	error	\N	\N	f	2026-06-04 20:07:23.990654-03
3	pbkdf2_sha256$600000$jGJCvcN9bFmaKMGfoxeMeq$YWxItmATSL6Qt//PQ15h6Zxz352zfygJcj+GXe4ZgHQ=	2026-06-05 11:47:45.358645-03	t	tiago				t	t	2026-01-10 22:30:06.305243-03	admin	\N	\N	\N	\N	\N	\N	\N	2026-01-10 22:30:06.305243-03	\N	123456	0.00	\N	\N	\N	43758965-2e8a-4c18-bb13-5c67487ffe30	\N	\N	\N	pending	\N	\N	f	2026-06-04 20:07:23.990654-03
4	pbkdf2_sha256$600000$YcrtUYHSPBlsx00k1vBqcy$loBtW5shFJqFsEsfh7yoroqcEX8i+9x8baBBhSVHhsQ=	\N	f	manoel	Manoel messias			f	t	2026-01-10 23:01:22.010043-03	cliente	2026-08-29	6.00	30.00		55 64 984545270	1	Manoel messias	2026-01-10 23:01:22.010043-03	3	1122	0.00	\N	\N	\N	ee97ed85-90f4-412c-b6ad-f2af87d762c4	\N	Erro 404: {"status":404,"error":"Not Found","response":{"message":["The \\"jbhb\\" instance does not exist"]}}	2026-01-25 12:13:46.824405-03	error	2026-01-18 12:13:46.824405-03	\N	f	2026-06-04 20:07:23.990654-03
13	pbkdf2_sha256$600000$UQNjWeWSvCeeV8thzB8qbD$ZoiKXl6APP1NkYa5rv2nxEni9D9Cm22p3dza2JtWPsA=	\N	f	Tiagos			thyagoa2015@hotmail.com	f	t	2026-06-04 19:45:42.152593-03	revenda	2026-06-07	0.00	0.00	\N	(64) 98168-8931	\N	arlindo cruz	2026-06-04 19:45:42.152593-03	3	\N	0.00	\N	\N	\N	d9c4aabd-ba15-4a8b-9c76-fe024044a758	\N	\N	2026-06-12 12:15:57.649038-03	found	2026-06-05 12:15:57.649038-03	https://pps.whatsapp.net/v/t61.24694-24/604013595_1524881422075346_2735566125605828191_n.jpg?ccb=11-4&oh=01_Q5Aa4wHxcji6Hmrgg998R3g8d2glCOjEyoM8MhZ2g4ZPlhVXfw&oe=6A2FE85B&_nc_sid=5e03e0&_nc_cat=106	f	2026-06-04 20:07:23.990654-03
9		\N	f	sdc	Manoel messiasedcd			f	t	2026-05-31 21:40:09.103265-03	cliente	2026-08-02	7.00	35.00		556492626113	2	Manoel messiasedcd	2026-05-31 21:40:09.103265-03	3	sdce	0.00	\N	\N	\N	1130e919-d644-46c9-ba3c-de278d23d226	\N	Erro 404: {"status":404,"error":"Not Found","response":{"message":["The \\"jbhb\\" instance does not exist"]}}	\N	error	\N	\N	f	2026-06-04 20:07:23.990654-03
6	pbkdf2_sha256$600000$paZEhJuYFsvvpAVjsoMYZb$duWKsesa114Zl3eqe8j/cBzqwKsK2VhRvr8LPH4NgCQ=	2026-01-11 18:45:05.307639-03	f	anna			thyagolyma2015@gmail.com	f	t	2026-01-11 18:44:55.57109-03	revenda	2026-06-03	0.00	0.00	\N	(64) 84545-270	\N	anna vitoria	2026-01-11 18:44:55.57109-03	3	\N	0.00	\N	\N	\N	045c679a-8f66-4b84-8e03-6257d60c6ba3	\N	\N	2026-06-11 19:10:14.7512-03	found	2026-06-04 19:10:14.7512-03	https://pps.whatsapp.net/v/t61.24694-24/534427908_3466591163498104_9079013649416032380_n.jpg?ccb=11-4&oh=01_Q5Aa4wFjyrm9TP9eOPTlNKIR3z3vYtM2-966yDeN-rZH1JvESw&oe=6A2F0B1A&_nc_sid=5e03e0&_nc_cat=100	f	2026-06-04 20:07:23.990654-03
10		\N	f	fcvrfdcgvf	zeca urubu			f	t	2026-06-02 23:25:11.890096-03	cliente	2026-06-25	\N	\N	sfedd	5564981688932	1	zeca urubu	2026-06-02 23:25:11.890096-03	3	\N	0.00	\N	\N	\N	d6c4ba3f-f8d5-479d-95fb-f8b996359a84	\N	Foto não encontrada	\N	not_found	\N	\N	f	2026-06-04 20:07:23.990654-03
\.


--
-- Data for Name: clientes_customuser_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_customuser_groups (id, customuser_id, group_id) FROM stdin;
\.


--
-- Data for Name: clientes_customuser_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_customuser_tags (id, customuser_id, tag_id) FROM stdin;
37	6	32
38	6	33
39	6	34
40	6	35
41	13	35
42	5	32
\.


--
-- Data for Name: clientes_customuser_user_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_customuser_user_permissions (id, customuser_id, permission_id) FROM stdin;
\.


--
-- Data for Name: clientes_financialentry; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_financialentry (id, description, amount, entry_type, category, entry_date, created_at, include_in_balance, scenario_id, user_id, updated_at) FROM stdin;
2	salario	1200.00	income		2026-01-16	2026-01-16 20:19:59.857998-03	t	1	3	2026-01-17 21:30:35.530943-03
23	meu agendado	100.00	income	lanche	2026-01-18	2026-01-18 11:42:58.274317-03	t	2	3	2026-01-18 11:42:58.274317-03
24	iptv	1000.00	income	renda extra	2026-01-18	2026-01-18 11:43:40.47851-03	t	2	3	2026-01-18 11:43:40.47851-03
25	financiamento casa	1200.00	expense	fixo	2026-01-18	2026-01-18 11:44:22.40513-03	t	2	3	2026-01-18 11:44:22.40513-03
27	meu agendado	4444.00	expense	variavel	2026-01-18	2026-01-18 11:51:19.193464-03	t	3	8	2026-01-18 11:51:19.193464-03
28	testes	100.00	income	fixo	2026-01-18	2026-01-18 12:36:31.241356-03	t	2	3	2026-01-18 12:36:31.241356-03
29	iptv2	30.00	income	Variável	2026-01-18	2026-01-18 12:56:35.186422-03	t	2	3	2026-01-18 12:56:35.186422-03
\.


--
-- Data for Name: clientes_financialscenario; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_financialscenario (id, name, description, is_default, created_at, user_id) FROM stdin;
1	Atual	Cenário financeiro atual	f	2026-01-16 20:02:34.571117-03	3
2	Teste	\N	t	2026-01-16 20:16:02.898629-03	3
3	Cenário Principal	Cenário padrão	t	2026-01-18 11:50:38.283539-03	8
\.


--
-- Data for Name: clientes_historicojogo; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_historicojogo (id, time_casa, time_fora, campeonato, horario, data_acesso, cliente_id) FROM stdin;
\.


--
-- Data for Name: clientes_historicomensagem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_historicomensagem (id, mensagem_final_enviada, data_tentativa, status, detalhes, cliente_id, mensagem_configurada_id) FROM stdin;
\.


--
-- Data for Name: clientes_indicacao; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_indicacao (id, data_indicacao, observacao, cliente_indicado_id, cliente_indicador_id) FROM stdin;
10	2026-06-02 21:45:43.651389-03	\N	5	4
16	2026-06-02 23:27:39.548447-03	\N	10	11
17	2026-06-03 12:25:51.834625-03	\N	11	8
\.


--
-- Data for Name: clientes_jogofavorito; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_jogofavorito (id, jogo_id, time_casa, time_fora, campeonato, criado_em, cliente_id) FROM stdin;
\.


--
-- Data for Name: clientes_logatividade; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_logatividade (id, tipo_acao, descricao, modelo_afetado, objeto_id, dados_antes, dados_depois, ip_address, user_agent, data_hora, duracao, status, url_acessada, metodo_http, usuario_id) FROM stdin;
2	login	Falha na autenticação para usuário: tiago1	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-10 22:29:04.875513-03	\N	falha	http://127.0.0.1:8000/login/	POST	\N
3	login	Falha na autenticação para usuário: tiago2	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-10 22:29:20.821948-03	\N	falha	http://127.0.0.1:8000/login/	POST	\N
4	login	Falha na autenticação para usuário: Tiago2	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-10 22:29:33.215259-03	\N	falha	http://127.0.0.1:8000/login/	POST	\N
5	login	Usuário tiago fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-10 22:30:25.339257-03	\N	sucesso	http://127.0.0.1:8000/login/	POST	3
6	login	Falha na autenticação para usuário: tiago2	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-10 22:35:08.861832-03	\N	falha	http://127.0.0.1:8000/login/	POST	\N
7	login	Falha na autenticação para usuário: tiago2	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-10 22:35:25.375282-03	\N	falha	http://127.0.0.1:8000/login/	POST	\N
8	login	Usuário tiago fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-10 22:35:33.46125-03	\N	sucesso	http://127.0.0.1:8000/login/	POST	3
9	logout	Usuário tiago saiu do sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-10 22:51:40.050382-03	\N	sucesso	http://127.0.0.1:8000/logout/	GET	3
10	login	Usuário tiago fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-10 22:51:48.669539-03	\N	sucesso	http://127.0.0.1:8000/login/	POST	3
11	create	Usuário tiago criou cliente: manoel (Manoel messias)	CustomUser	4	\N	{"nome": "Manoel messias", "plano": "club", "username": "manoel", "tipo_usuario": "cliente", "data_vencimento": "2026-01-17"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-10 23:01:22.029081-03	\N	sucesso	http://127.0.0.1:8000/cadastrar_cliente/	POST	3
12	envio_msg	Mensagem de boas-vindas enviada para cliente manoel	CustomUser	4	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-10 23:01:22.036601-03	\N	sucesso	http://127.0.0.1:8000/cadastrar_cliente/	POST	3
13	update	Usuário tiago editou cliente: manoel	CustomUser	4	{"nome": "Manoel messias", "plano": "club", "username": "manoel", "whatsapp": "55 64 8454-5270", "is_active": true, "data_vencimento": "2026-01-17"}	{"nome": "Manoel messias", "tags": [], "plano": "club", "username": "manoel", "whatsapp": "55 64 84545270", "is_active": true, "data_vencimento": "2026-01-17"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-10 23:01:39.881593-03	\N	sucesso	http://127.0.0.1:8000/editar_cliente/4/	POST	3
14	update	Usuário tiago editou cliente: manoel	CustomUser	4	{"nome": "Manoel messias", "plano": "club", "username": "manoel", "whatsapp": "55 64 84545270", "is_active": true, "data_vencimento": "2026-01-17"}	{"nome": "Manoel messias", "tags": [], "plano": "club", "username": "manoel", "whatsapp": "55 64 984545270", "is_active": true, "data_vencimento": "2026-01-17"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-10 23:01:52.853017-03	\N	sucesso	http://127.0.0.1:8000/editar_cliente/4/	POST	3
15	create	Usuário tiago criou cliente: raimundo (Raimundo)	CustomUser	5	\N	{"nome": "Raimundo", "plano": "club", "username": "raimundo", "tipo_usuario": "cliente", "data_vencimento": "2026-01-11"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-10 23:05:43.263514-03	\N	sucesso	http://127.0.0.1:8000/cadastrar_cliente/	POST	3
16	envio_msg	Mensagem de boas-vindas enviada para cliente raimundo	CustomUser	5	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-10 23:05:43.270495-03	\N	sucesso	http://127.0.0.1:8000/cadastrar_cliente/	POST	3
17	renovacao	Usuário tiago renovou cliente raimundo para 2026-02-10	CustomUser	5	{"data_vencimento": "2026-01-11"}	{"data_vencimento": "2026-02-10"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-10 23:16:04.917618-03	\N	sucesso	http://127.0.0.1:8000/renovar-cliente/5/	POST	3
18	envio_msg	Mensagem de confirmação de renovação enviada para cliente raimundo	CustomUser	5	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-10 23:16:04.948601-03	\N	sucesso	http://127.0.0.1:8000/renovar-cliente/5/	POST	3
19	logout	Usuário tiago saiu do sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-11 11:30:44.437273-03	\N	sucesso	http://127.0.0.1:8000/logout/	GET	3
20	login	Usuário tiago fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-11 11:30:52.844996-03	\N	sucesso	http://127.0.0.1:8000/login/	POST	3
21	logout	Usuário tiago saiu do sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-11 11:31:59.50022-03	\N	sucesso	http://127.0.0.1:8000/logout/	GET	3
22	login	Usuário tiago fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-11 11:32:08.511046-03	\N	sucesso	http://127.0.0.1:8000/login/	POST	3
23	logout	Usuário tiago saiu do sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-11 12:34:14.468958-03	\N	sucesso	http://127.0.0.1:8000/logout/	GET	3
24	login	Usuário tiago fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-11 12:34:22.040458-03	\N	sucesso	http://127.0.0.1:8000/login/	POST	3
25	logout	Usuário tiago saiu do sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-11 18:44:18.179577-03	\N	sucesso	http://127.0.0.1:8000/logout/	GET	3
26	login	Usuário anna fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-11 18:45:05.312636-03	\N	sucesso	http://127.0.0.1:8000/login/	POST	6
27	logout	Usuário anna saiu do sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-11 21:46:32.303214-03	\N	sucesso	http://127.0.0.1:8000/logout/	GET	6
28	login	Usuário tiago fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	2026-01-11 21:46:41.579067-03	\N	sucesso	http://127.0.0.1:8000/login/	POST	3
29	login	Usuário tiago fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-15 20:40:48.142784-03	\N	sucesso	http://127.0.0.1:8000/login/	POST	3
30	login	Usuário tiago fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-16 20:09:33.886366-03	\N	sucesso	http://localhost:8000/login/	POST	3
31	logout	Usuário tiago saiu do sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-18 11:47:39.112402-03	\N	sucesso	http://127.0.0.1:8000/logout/	GET	3
32	login	Falha na autenticação para usuário: fernando	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-18 11:48:25.427477-03	\N	falha	http://127.0.0.1:8000/login/	POST	\N
33	login	Falha na autenticação para usuário: fernando	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-18 11:48:32.98549-03	\N	falha	http://127.0.0.1:8000/login/	POST	\N
34	login	Falha na autenticação para usuário: fernando	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-18 11:48:40.286209-03	\N	falha	http://127.0.0.1:8000/login/	POST	\N
35	login	Usuário tiago fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-18 11:48:50.777599-03	\N	sucesso	http://127.0.0.1:8000/login/	POST	3
36	delete	Usuário tiago excluiu cliente: 12345	CustomUser	7	{"nome": "fernando", "email": "thyagolyma2015@fhotmail.com", "plano": null, "username": "12345", "whatsapp": "(55) 44998-6639", "data_vencimento": "2026-01-21"}	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-18 11:49:36.454145-03	\N	sucesso	http://127.0.0.1:8000/excluir_cliente/7/	POST	3
37	logout	Usuário tiago saiu do sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-18 11:49:42.194153-03	\N	sucesso	http://127.0.0.1:8000/logout/	GET	3
38	login	Usuário fernando fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-18 11:50:32.840913-03	\N	sucesso	http://127.0.0.1:8000/login/	POST	8
39	logout	Usuário fernando saiu do sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-18 11:52:00.597278-03	\N	sucesso	http://127.0.0.1:8000/logout/	GET	8
40	login	Usuário tiago fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	2026-01-18 11:52:08.831393-03	\N	sucesso	http://127.0.0.1:8000/login/	POST	3
41	login	Usuário tiago fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-06 20:47:24.366892-03	\N	sucesso	http://127.0.0.1:8000/login/	POST	3
42	renovacao	Usuário tiago renovou cliente anna para 2026-04-08	CustomUser	6	{"data_vencimento": "2026-01-14"}	{"data_vencimento": "2026-04-08"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-06 22:40:10.851241-03	\N	sucesso	http://127.0.0.1:8000/renovar-cliente/6/	POST	3
43	renovacao	Usuário tiago renovou cliente fernando para 2026-04-07	CustomUser	8	{"data_vencimento": "2026-01-21"}	{"data_vencimento": "2026-04-07"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-07 00:22:38.603963-03	\N	sucesso	http://127.0.0.1:8000/renovar-cliente/8/	POST	3
44	login	Usuário tiago fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	2026-04-17 11:33:16.262027-03	\N	sucesso	http://127.0.0.1:8000/login/	POST	3
45	login	Usuário tiago fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-31 19:56:05.191401-03	\N	sucesso	http://127.0.0.1:8000/login/	POST	3
46	renovacao	Usuário tiago renovou cliente manoel para 2026-06-30	CustomUser	4	{"data_vencimento": "2026-01-17"}	{"data_vencimento": "2026-06-30"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-31 20:06:47.295886-03	\N	sucesso	http://127.0.0.1:8000/renovar-cliente/4/	POST	3
47	create	Usuário tiago criou cliente: sdc (Manoel messiasedcd)	CustomUser	9	\N	{"nome": "Manoel messiasedcd", "plano": "club", "username": "sdc", "tipo_usuario": "cliente", "data_vencimento": "2026-06-03"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-05-31 21:40:09.169865-03	\N	sucesso	http://127.0.0.1:8000/cadastrar_cliente/	POST	3
48	renovacao	Usuário tiago renovou cliente anna para 2026-06-03	CustomUser	6	{"data_vencimento": "2026-04-08"}	{"data_vencimento": "2026-06-03"}	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1	2026-06-02 19:17:26.930773-03	\N	sucesso	http://127.0.0.1:8000/renovar-cliente/6/	POST	3
49	pagamento	Comissão de R$ 5.00 para Raimundo por indicação de Manoel messiasedcd	CustomUser	5	\N	\N	\N	\N	2026-06-02 21:15:44.480084-03	\N	sucesso	\N	\N	3
50	pagamento	Comissão de R$ 3.00 para fernando por indicação de Manoel messiasedcd	CustomUser	8	\N	\N	\N	\N	2026-06-02 21:24:31.617678-03	\N	sucesso	\N	\N	3
51	update	Usuário tiago editou cliente: fernando	CustomUser	8	{"nome": "fernando", "plano": null, "username": "fernando", "whatsapp": "(55) 44998-6639", "is_active": true, "data_vencimento": "2026-04-07"}	{"nome": "fernando", "tags": [], "plano": "club", "username": "fernando", "whatsapp": "(55) 44998-6639", "is_active": true, "data_vencimento": "2026-04-07"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-02 21:25:01.589765-03	\N	sucesso	http://127.0.0.1:8000/editar_cliente/8/	POST	3
52	renovacao	Usuário tiago renovou cliente sdc para 2026-07-03	CustomUser	9	{"data_vencimento": "2026-06-03"}	{"data_vencimento": "2026-07-03"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-02 21:26:05.680648-03	\N	sucesso	http://127.0.0.1:8000/renovar-cliente/9/	POST	3
53	renovacao	Usuário tiago renovou cliente manoel para 2026-07-30	CustomUser	4	{"data_vencimento": "2026-06-30"}	{"data_vencimento": "2026-07-30"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-02 21:32:58.110111-03	\N	sucesso	http://127.0.0.1:8000/renovar-cliente/4/	POST	3
54	renovacao	Usuário tiago renovou cliente sdc para 2026-08-02	CustomUser	9	{"data_vencimento": "2026-07-03"}	{"data_vencimento": "2026-08-02"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-02 21:44:52.76366-03	\N	sucesso	http://127.0.0.1:8000/renovar-cliente/9/	POST	3
55	renovacao	Usuário tiago renovou cliente raimundo para 2026-07-03	CustomUser	5	{"data_vencimento": "2026-02-10"}	{"data_vencimento": "2026-07-03"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-02 21:46:14.516086-03	\N	sucesso	http://127.0.0.1:8000/renovar-cliente/5/	POST	3
56	renovacao	Usuário tiago renovou cliente manoel para 2026-08-29	CustomUser	4	{"data_vencimento": "2026-07-30"}	{"data_vencimento": "2026-08-29"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-02 21:48:29.838368-03	\N	sucesso	http://127.0.0.1:8000/renovar-cliente/4/	POST	3
57	update	Usuário tiago editou cliente: sdc	CustomUser	9	{"nome": "Manoel messiasedcd", "plano": "club", "username": "sdc", "whatsapp": "556492626113", "is_active": true, "data_vencimento": "2026-08-02"}	{"nome": "Manoel messiasedcd", "tags": [], "plano": "club", "username": "sdc", "whatsapp": "556492626113", "is_active": true, "data_vencimento": "2026-06-02"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-02 21:52:00.459475-03	\N	sucesso	http://127.0.0.1:8000/editar_cliente/9/	POST	3
58	pagamento	Comissão de R$1.00 recebida pela renovação de Manoel messiasedcd	\N	\N	\N	\N	\N	\N	2026-06-02 21:52:53.061278-03	\N	sucesso	\N	\N	8
59	renovacao	Usuário tiago renovou cliente sdc para 2026-07-03	CustomUser	9	{"data_vencimento": "2026-06-02"}	{"data_vencimento": "2026-07-03"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-02 21:52:53.086302-03	\N	sucesso	http://127.0.0.1:8000/renovar-cliente/9/	POST	3
60	renovacao	Usuário tiago renovou cliente sdc para 2026-08-02	CustomUser	9	{"data_vencimento": "2026-07-03"}	{"data_vencimento": "2026-08-02"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-02 21:57:13.908162-03	\N	sucesso	http://127.0.0.1:8000/renovar-cliente/9/	POST	3
61	pagamento	Bônus meta 1x (2 indicações) para fernando - Total: 2 indicações - R$ 23.00	CustomUser	8	\N	\N	\N	\N	2026-06-02 22:10:50.23516-03	\N	sucesso	\N	\N	3
62	create	Usuário tiago criou cliente: fcvrfdcgvf (zeca urubu)	CustomUser	10	\N	{"nome": "zeca urubu", "plano": "club", "username": "fcvrfdcgvf", "tipo_usuario": "cliente", "data_vencimento": "2026-06-25"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-02 23:25:11.940094-03	\N	sucesso	http://127.0.0.1:8000/cadastrar_cliente/	POST	3
63	create	Usuário tiago criou cliente: dfhedxvg (amanda)	CustomUser	11	\N	{"nome": "amanda", "plano": "club", "username": "dfhedxvg", "tipo_usuario": "cliente", "data_vencimento": "2026-06-12"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-02 23:27:03.815038-03	\N	sucesso	http://127.0.0.1:8000/cadastrar_cliente/	POST	3
64	update	Usuário tiago editou cliente: fernando	CustomUser	8	{"nome": "fernando", "plano": "club", "username": "fernando", "whatsapp": "(55) 44998-6639", "is_active": true, "data_vencimento": "2026-04-07"}	{"nome": "fernando2", "tags": [], "plano": "club", "username": "fernando", "whatsapp": "(55) 44998-6639", "is_active": true, "data_vencimento": "2026-04-07"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-02 23:32:12.119897-03	\N	sucesso	http://127.0.0.1:8000/editar_cliente/8/	POST	3
65	create	Usuário tiago criou cliente: pachequinho (pachego)	CustomUser	12	\N	{"nome": "pachego", "plano": "club", "username": "pachequinho", "tipo_usuario": "cliente", "data_vencimento": "2026-06-24"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 12:15:42.666033-03	\N	sucesso	http://127.0.0.1:8000/cadastrar_cliente/	POST	3
66	update	Usuário tiago editou cliente: pachequinho	CustomUser	12	{"nome": "pachego", "plano": "club", "username": "pachequinho", "whatsapp": "5599999999999", "is_active": true, "data_vencimento": "2026-06-24"}	{"nome": "pachego", "tags": [], "plano": "club", "username": "pachequinho", "whatsapp": "5599999999999", "is_active": true, "data_vencimento": "2026-06-24"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 12:16:18.93415-03	\N	sucesso	http://127.0.0.1:8000/editar_cliente/12/	POST	3
67	update	Usuário tiago editou cliente: fernando	CustomUser	8	{"nome": "fernando2", "plano": "club", "username": "fernando", "whatsapp": "(55) 44998-6639", "is_active": true, "data_vencimento": "2026-04-07"}	{"nome": "fernando2", "tags": ["teste", "teste mais novo"], "plano": "club", "username": "fernando", "whatsapp": "(55) 44998-6639", "is_active": true, "data_vencimento": "2026-04-07"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 12:24:36.743083-03	\N	sucesso	http://127.0.0.1:8000/editar_cliente/8/	POST	3
68	update	Usuário tiago editou cliente: fernando	CustomUser	8	{"nome": "fernando2", "plano": "club", "username": "fernando", "whatsapp": "(55) 44998-6639", "is_active": true, "data_vencimento": "2026-04-07"}	{"nome": "fernando2", "tags": ["teste", "teste mais novo"], "plano": "spark", "username": "fernando", "whatsapp": "(55) 44998-6639", "is_active": true, "data_vencimento": "2026-04-07"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 12:36:13.203539-03	\N	sucesso	http://127.0.0.1:8000/editar_cliente/8/	POST	3
69	update	Usuário tiago editou cliente: fcvrfdcgvf	CustomUser	10	{"nome": "zeca urubu", "plano": "club", "username": "fcvrfdcgvf", "whatsapp": "5564981688931", "is_active": true, "data_vencimento": "2026-06-25"}	{"nome": "zeca urubu", "tags": ["teste mais novo"], "plano": "club", "username": "fcvrfdcgvf", "whatsapp": "5564981688932", "is_active": true, "data_vencimento": "2026-06-25"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 12:36:50.570368-03	\N	sucesso	http://127.0.0.1:8000/editar_cliente/10/	POST	3
70	renovacao	Usuário tiago renovou cliente dfhedxvg para 2026-07-12	CustomUser	11	{"data_vencimento": "2026-06-12"}	{"data_vencimento": "2026-07-12"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 20:49:02.180761-03	\N	sucesso	http://127.0.0.1:8000/renovar-cliente/11/	POST	3
71	delete	Usuário tiago excluiu cliente: pachego	CustomUser	12	{"nome": "pachego", "email": "", "plano": "club", "username": "pachequinho", "whatsapp": "5599999999999", "data_vencimento": "2026-06-24"}	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 20:51:00.665106-03	\N	sucesso	http://127.0.0.1:8000/excluir_cliente/12/	POST	3
72	logout	Usuário tiago saiu do sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 21:00:49.570989-03	\N	sucesso	http://127.0.0.1:8000/logout/	GET	3
73	login	Usuário tiago fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 21:01:07.514618-03	\N	sucesso	http://127.0.0.1:8000/login/	POST	3
74	logout	Usuário tiago saiu do sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 21:06:12.91426-03	\N	sucesso	http://127.0.0.1:8000/logout/	GET	3
75	login	Usuário tiago fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 21:06:24.666955-03	\N	sucesso	http://127.0.0.1:8000/login/	POST	3
76	logout	Usuário tiago saiu do sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-04 11:48:05.596213-03	\N	sucesso	http://127.0.0.1:8000/logout/	GET	3
77	login	Usuário tiago fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-04 12:02:47.568678-03	\N	sucesso	http://127.0.0.1:8000/login/	POST	3
78	logout	Usuário tiago saiu do sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-04 12:02:53.69461-03	\N	sucesso	http://127.0.0.1:8000/logout/	GET	3
79	login	Usuário tiago fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-04 12:03:12.349627-03	\N	sucesso	http://127.0.0.1:8000/login/	POST	3
80	logout	Usuário tiago saiu do sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-04 12:03:15.762443-03	\N	sucesso	http://127.0.0.1:8000/logout/	GET	3
81	login	Usuário tiago fez login no sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1	2026-06-04 12:04:32.618636-03	\N	sucesso	http://127.0.0.1:8000/login/	POST	3
82	logout	Usuário tiago saiu do sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-04 12:05:01.54188-03	\N	sucesso	http://127.0.0.1:8000/logout/	GET	3
83	logout	Usuário tiago saiu do sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-04 12:35:48.558842-03	\N	sucesso	http://127.0.0.1:8000/logout/	GET	3
84	update	Usuário tiago editou cliente: dfhedxvg	CustomUser	11	{"nome": "amanda", "plano": "club", "username": "dfhedxvg", "whatsapp": "5564981688931", "is_active": true, "valor_a_pagar": "30.00", "valor_servico": "6.00", "data_vencimento": "2026-07-12"}	{"nome": "amanda", "tags": ["teste", "teste mais novo"], "plano": "spark", "username": "dfhedxvg", "whatsapp": "5564981688931", "is_active": true, "valor_a_pagar": "35.00", "valor_servico": "7.00", "data_vencimento": "2026-07-12"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-04 16:58:21.227086-03	\N	sucesso	http://127.0.0.1:8000/editar_cliente/11/	POST	3
85	update	Usuário tiago editou cliente: sdc	CustomUser	9	{"nome": "Manoel messiasedcd", "plano": "club", "username": "sdc", "whatsapp": "556492626113", "is_active": true, "valor_a_pagar": "30.00", "valor_servico": "6.00", "data_vencimento": "2026-08-02"}	{"nome": "Manoel messiasedcd", "tags": [], "plano": "spark", "username": "sdc", "whatsapp": "556492626113", "is_active": true, "valor_a_pagar": "35.00", "valor_servico": "7.00", "data_vencimento": "2026-08-02"}	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-04 16:58:52.588491-03	\N	sucesso	http://127.0.0.1:8000/editar_cliente/9/	POST	3
86	logout	Usuário tiago saiu do sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-04 19:38:15.540462-03	\N	sucesso	http://127.0.0.1:8000/logout/	GET	3
87	logout	Usuário tiago saiu do sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-04 19:44:18.172363-03	\N	sucesso	http://127.0.0.1:8000/logout/	GET	3
88	logout	Usuário tiago saiu do sistema	\N	\N	\N	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-04 21:30:08.853772-03	\N	sucesso	http://127.0.0.1:8000/logout/	GET	3
\.


--
-- Data for Name: clientes_mensagem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_mensagem (id, conteudo, data_envio, usuario_id, numero, status) FROM stdin;
\.


--
-- Data for Name: clientes_mensagemconfigurada; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_mensagemconfigurada (id, criterio_dias, mensagem_texto, horario_envio, configuracao_id) FROM stdin;
\.


--
-- Data for Name: clientes_message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_message (id, content, "timestamp", is_read, receiver_id, sender_id) FROM stdin;
\.


--
-- Data for Name: clientes_movimentacaocaixa; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_movimentacaocaixa (id, tipo, valor, descricao, categoria, data, usuario_id) FROM stdin;
\.


--
-- Data for Name: clientes_relatoriofinanceiro; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_relatoriofinanceiro (id, valor_pago, valor_servico, valor_liquido, servidor, data_geracao, cliente_id, is_manual) FROM stdin;
1	30.00	6.00	24.00	club	2026-01-10 23:05:43.271494-03	5	f
2	30.00	6.00	24.00	club	2026-01-10 23:16:04.868688-03	5	f
3	0.00	0.00	0.00	Automático (Sem Plano)	2026-04-06 22:40:10.811401-03	6	f
4	0.00	0.00	0.00	Automático (Sem Plano)	2026-04-07 00:22:38.50299-03	8	f
5	30.00	6.00	24.00	club	2026-05-31 20:06:47.274882-03	4	f
6	30.00	6.00	24.00	club	2026-05-31 21:40:09.202148-03	9	f
7	0.00	0.00	0.00	Automático (Sem Plano)	2026-06-02 19:17:26.917386-03	6	f
8	30.00	6.00	24.00	club	2026-06-02 21:26:05.648169-03	9	f
9	30.00	6.00	24.00	club	2026-06-02 21:32:58.092106-03	4	f
10	30.00	6.00	24.00	club	2026-06-02 21:44:52.673121-03	9	f
11	25.00	6.00	19.00	club	2026-06-02 21:46:14.47208-03	5	f
12	25.00	6.00	19.00	club	2026-06-02 21:48:29.805361-03	4	f
13	30.00	6.00	24.00	club	2026-06-02 21:52:52.891515-03	9	f
14	30.00	6.00	24.00	club	2026-06-02 21:57:13.888058-03	9	f
15	30.00	6.00	24.00	club	2026-06-02 23:25:11.97157-03	10	f
16	30.00	6.00	24.00	club	2026-06-02 23:27:03.818041-03	11	f
18	30.00	6.00	24.00	club	2026-06-03 20:49:02.104114-03	11	f
\.


--
-- Data for Name: clientes_servico; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_servico (id, nome, valor, cor, observacao, revenda_id, custos) FROM stdin;
1	club	30.00	#151414		3	6.00
2	spark	35.00	#d31d90		3	7.00
\.


--
-- Data for Name: clientes_tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_tag (id, descricao, nome, cor, data_criacao, usuario_id) FROM stdin;
31	\N	dszd	#7c8092	2026-06-05 12:47:37.106255-03	3
32	\N	dxdcesxds	#0e37ec	2026-06-05 12:47:51.32466-03	3
33	\N	dxfcdsxfcsxc	#667eea	2026-06-05 12:48:01.372632-03	3
34	\N	dxfcdxfcsdcsx	#9222dd	2026-06-05 12:48:17.442774-03	3
35	\N	dxfcdxdfc	#0020ad	2026-06-05 12:48:37.392326-03	3
\.


--
-- Data for Name: clientes_tutorial; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_tutorial (id, titulo, descricao, video_url, data_criacao) FROM stdin;
\.


--
-- Data for Name: clientes_verificationcode; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes_verificationcode (id, code, created_at, expires_at, is_used, session_key, code_type, whatsapp_number) FROM stdin;
27	7507	2026-06-05 11:47:33.833723-03	2026-06-05 11:52:33.83272-03	t	no5ll2fur4ope43mskk66lcimiwjxhsq	login	\N
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
3	2026-01-10 22:34:37.066057-03	2	tiago2 (Admin)	2	[{"changed": {"fields": ["User permissions", "Data vencimento", "Dono", "Senha leitura"]}}]	7	3
4	2026-01-10 22:58:21.76894-03	2	tiago2 (Admin)	3		7	3
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	contenttypes	contenttype
5	sessions	session
6	sites	site
7	clientes	customuser
8	clientes	relatoriofinanceiro
9	clientes	servico
10	clientes	tag
11	clientes	mensagem
12	clientes	configuracaomensagem
13	clientes	message
14	clientes	configuracao
15	clientes	atualizacao
16	clientes	mensagemconfigurada
17	clientes	tutorial
18	clientes	historicomensagem
19	clientes	movimentacaocaixa
20	clientes	logatividade
21	whatsapp_integration	userinstance
22	whatsapp_integration	historicomensagemautomatica
23	whatsapp_integration	mensagemmassa
24	whatsapp_integration	historicoenviomassa
25	clientes	financialscenario
26	clientes	financialentry
27	clientes	jogofavorito
28	clientes	historicojogo
29	clientes	indicacao
30	clientes	configuracaoindicacao
31	clientes	verificationcode
32	clientes	backuphistory
33	clientes	backupschedule
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2026-01-10 21:46:48.650607-03
2	contenttypes	0002_remove_content_type_name	2026-01-10 21:46:48.659616-03
3	auth	0001_initial	2026-01-10 21:46:48.699379-03
4	auth	0002_alter_permission_name_max_length	2026-01-10 21:46:48.701377-03
5	auth	0003_alter_user_email_max_length	2026-01-10 21:46:48.704889-03
6	auth	0004_alter_user_username_opts	2026-01-10 21:46:48.708166-03
7	auth	0005_alter_user_last_login_null	2026-01-10 21:46:48.713195-03
8	auth	0006_require_contenttypes_0002	2026-01-10 21:46:48.71473-03
9	auth	0007_alter_validators_add_error_messages	2026-01-10 21:46:48.717732-03
10	auth	0008_alter_user_username_max_length	2026-01-10 21:46:48.72073-03
11	auth	0009_alter_user_last_name_max_length	2026-01-10 21:46:48.725303-03
12	auth	0010_alter_group_name_max_length	2026-01-10 21:46:48.731935-03
13	auth	0011_update_proxy_permissions	2026-01-10 21:46:48.73545-03
14	auth	0012_alter_user_first_name_max_length	2026-01-10 21:46:48.739449-03
15	clientes	0001_initial	2026-01-10 21:46:48.797325-03
16	admin	0001_initial	2026-01-10 21:46:48.812524-03
17	admin	0002_logentry_remove_auto_add	2026-01-10 21:46:48.817523-03
18	admin	0003_logentry_add_action_flag_choices	2026-01-10 21:46:48.823397-03
19	clientes	0002_remove_customuser_tipo_revenda_customuser_dono	2026-01-10 21:46:48.83831-03
20	clientes	0003_remove_customuser_dono_alter_customuser_plano	2026-01-10 21:46:48.85721-03
21	clientes	0004_customuser_dono	2026-01-10 21:46:48.869679-03
22	clientes	0005_customuser_senha_leitura	2026-01-10 21:46:48.876243-03
23	clientes	0006_customuser_nome	2026-01-10 21:46:48.883153-03
24	clientes	0007_tag_remove_customuser_data_criacao_and_more	2026-01-10 21:46:48.922888-03
25	clientes	0008_customuser_data_criacao_customuser_dono_and_more	2026-01-10 21:46:48.939884-03
26	clientes	0009_customuser_saldo	2026-01-10 21:46:48.949165-03
27	clientes	0010_remove_tag_name_tag_descricao_tag_nome_and_more	2026-01-10 21:46:48.970482-03
28	clientes	0011_customuser_pix_code_customuser_pix_code_base64_and_more	2026-01-10 21:46:48.987014-03
29	clientes	0012_customuser_instance_name	2026-01-10 21:46:48.994541-03
30	clientes	0013_mensagem	2026-01-10 21:46:49.00804-03
31	clientes	0014_rename_horario_envio_mensagem_data_envio_and_more	2026-01-10 21:46:49.084034-03
32	clientes	0015_configuracaomensagem	2026-01-10 21:46:49.091529-03
33	clientes	0016_remove_configuracaomensagem_excecoes_and_more	2026-01-10 21:46:49.107091-03
34	clientes	0017_remove_configuracaomensagem_enviar_apos_vencimento_and_more	2026-01-10 21:46:49.115956-03
35	clientes	0018_alter_configuracaomensagem_dias_antes_vencimento_and_more	2026-01-10 21:46:49.122968-03
36	clientes	0019_message	2026-01-10 21:46:49.141014-03
37	clientes	0020_alter_message_timestamp	2026-01-10 21:46:49.14951-03
38	clientes	0021_configuracao	2026-01-10 21:46:49.170289-03
39	clientes	0022_alter_configuracao_senha	2026-01-10 21:46:49.186365-03
40	clientes	0023_alter_configuracao_usuario	2026-01-10 21:46:49.206423-03
41	clientes	0024_remove_configuracao_api_telegram_configuracao_email_and_more	2026-01-10 21:46:49.24831-03
42	clientes	0025_remove_configuracaomensagem_hora_execucao	2026-01-10 21:46:49.252257-03
43	clientes	0026_atualizacao	2026-01-10 21:46:49.259263-03
44	clientes	0027_remove_atualizacao_imagens_and_more	2026-01-10 21:46:49.269345-03
45	clientes	0028_atualizacao_imagem	2026-01-10 21:46:49.272905-03
46	clientes	0029_userinstance	2026-01-10 21:46:49.287152-03
47	clientes	0030_remove_configuracao_api_whatsapp_and_more	2026-01-10 21:46:49.300039-03
48	clientes	0031_configuracaomensagem_usuario	2026-01-10 21:46:49.309961-03
49	clientes	0032_servico_custos_alter_servico_valor	2026-01-10 21:46:49.323929-03
50	clientes	0033_remove_configuracaomensagem_dias_antes_vencimento_and_more	2026-01-10 21:46:49.376064-03
51	clientes	0034_alter_mensagemconfigurada_horario_envio	2026-01-10 21:46:49.380063-03
52	clientes	0035_remove_userinstance_created_at_and_more	2026-01-10 21:46:49.392572-03
53	clientes	0036_relatoriofinanceiro_is_manual	2026-01-10 21:46:49.401748-03
54	clientes	0037_customuser_ajuste_recorrente	2026-01-10 21:46:49.412302-03
55	clientes	0038_remove_customuser_ajuste_recorrente	2026-01-10 21:46:49.422389-03
56	clientes	0039_tutorial	2026-01-10 21:46:49.432387-03
57	clientes	0040_alter_tutorial_video_url	2026-01-10 21:46:49.436393-03
58	clientes	0041_alter_tutorial_options_alter_tutorial_data_criacao_and_more	2026-01-10 21:46:49.443934-03
59	clientes	0042_alter_customuser_is_active	2026-01-10 21:46:49.452481-03
60	clientes	0043_delete_userinstance	2026-01-10 21:46:49.456498-03
61	clientes	0044_historicomensagemautomatica	2026-01-10 21:46:49.481213-03
62	clientes	0045_remove_customuser_instance_name	2026-01-10 21:46:49.490205-03
63	clientes	0046_alter_mensagemconfigurada_mensagem_texto	2026-01-10 21:46:49.49519-03
64	clientes	0047_delete_historicomensagemautomatica	2026-01-10 21:46:49.499188-03
65	clientes	0048_historicomensagem	2026-01-10 21:46:49.519876-03
66	clientes	0049_customuser_link_acesso	2026-01-10 21:46:49.529297-03
67	clientes	0050_customuser_whatsapp_avatar_base64_and_more	2026-01-10 21:46:49.573447-03
68	clientes	0051_alter_configuracaomensagem_usuario	2026-01-10 21:46:49.589769-03
69	clientes	0052_alter_configuracaomensagem_usuario	2026-01-10 21:46:49.658448-03
70	clientes	0053_movimentacaocaixa	2026-01-10 21:46:49.679094-03
71	clientes	0054_alter_configuracaomensagem_usuario	2026-01-10 21:46:49.692823-03
72	clientes	0055_remove_movimentacaocaixa_created_at_and_more	2026-01-10 21:46:49.70984-03
73	clientes	0056_alter_customuser_whatsapp	2026-01-10 21:46:49.721059-03
74	clientes	0057_logatividade	2026-01-10 21:46:49.738917-03
75	sessions	0001_initial	2026-01-10 21:46:49.74852-03
76	sites	0001_initial	2026-01-10 21:46:49.75308-03
77	sites	0002_alter_domain_unique	2026-01-10 21:46:49.758592-03
78	whatsapp_integration	0001_initial	2026-01-10 21:46:49.778729-03
79	whatsapp_integration	0002_remove_userinstance_api_key_and_more	2026-01-10 21:46:49.851441-03
80	whatsapp_integration	0003_mensagemconfigurada_historicomensagemautomatica	2026-01-10 21:46:49.886954-03
81	whatsapp_integration	0004_alter_historicomensagemautomatica_mensagem_configurada_and_more	2026-01-10 21:46:50.011584-03
82	whatsapp_integration	0005_alter_historicomensagemautomatica_data_envio	2026-01-10 21:46:50.023137-03
83	whatsapp_integration	0006_mensagemmassa	2026-01-10 21:46:50.053531-03
84	whatsapp_integration	0007_alter_userinstance_options_and_more	2026-01-10 21:46:50.230384-03
85	whatsapp_integration	0008_alter_userinstance_options_and_more	2026-01-10 21:46:50.315043-03
86	whatsapp_integration	0009_alter_userinstance_options_and_more	2026-01-10 21:46:50.385205-03
87	whatsapp_integration	0010_alter_mensagemmassa_options_and_more	2026-01-10 21:46:50.558995-03
88	whatsapp_integration	0011_historicoenviomassa_and_more	2026-01-10 21:46:50.8636-03
89	whatsapp_integration	0012_alter_historicoenviomassa_options_and_more	2026-01-10 21:46:51.272824-03
90	clientes	0058_alter_atualizacao_id_alter_configuracao_id_and_more	2026-01-16 19:54:18.214205-03
91	clientes	0059_fix_default_auto_field	2026-01-16 19:58:34.347443-03
92	clientes	0060_alter_financialentry_options_and_more	2026-01-16 21:11:38.81717-03
93	clientes	0061_remove_financialentry_group_and_more	2026-01-17 21:30:35.570941-03
94	clientes	0062_alter_financialentry_options_and_more	2026-01-18 11:25:36.888159-03
95	clientes	0063_alter_financialscenario_options	2026-01-18 11:42:35.925143-03
96	clientes	0064_jogofavorito_historicojogo	2026-04-06 21:29:13.176424-03
97	clientes	0065_alter_tag_options_tag_cor_tag_data_criacao_and_more	2026-05-31 22:12:13.170055-03
98	clientes	0066_alter_tag_nome	2026-06-01 23:14:11.628783-03
99	clientes	0067_configuracaoindicacao	2026-06-02 20:41:14.070245-03
100	clientes	0068_remove_configuracaoindicacao_usuario_and_more	2026-06-02 21:06:48.368474-03
101	clientes	0069_verificationcode	2026-06-04 12:02:03.462641-03
102	clientes	0070_verificationcode_code_type_and_more	2026-06-04 12:34:52.96064-03
103	clientes	0071_customuser_cadastro_online_customuser_data_cadastro	2026-06-04 20:07:23.993653-03
104	clientes	0072_backupschedule_backuphistory	2026-06-04 21:22:48.627447-03
105	clientes	0073_backuphistory_google_drive_file_id	2026-06-05 20:12:59.400007-03
106	clientes	0074_remove_backuphistory_google_drive_file_id_and_more	2026-06-06 11:38:23.058402-03
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
c3ewl4shlkcoxm2t9n8fvrzxqzd78gue	.eJxVjcsOwiAURP-FddNQ7gWKS_d-A-Fp8QFNaRON8d9tTRe6nTlz5kW0WeZBLzVMOnlyIECa38wadw15K_zF5HNpXcnzlGy7Ie3e1vZUfLgdd_ZPMJg6rGtJFQIgOAGCo6IQuewg8B6ZcJxJVJEyCxGE6jlnMVhkjoXOKxSGKrlJa6g1lazDY0zTkxx6gZQ25Hszp7GsN8bfUybvDyhTROg:1w9xa3:MLRkOmRHmBxajRMF71c1Ms7esl0oABYh36dkOMmHQoI	2026-04-08 00:58:23.423515-03
fzilu4n75txli644t8jddxiqcsfz9j5v	.eJxVjDsOwjAQBe_iGlnJ2vFiSnrOEO16DTEfG-VTIe6Og1JA-2bevFRPyzz0yxTHPok6KKN2vxtTuMW8ArlSvhQdSp7HxHpV9EYnfSoS78fN_QsMNA313SIgcCOWgwVisN4Ad-JaJGNIEJ1HOntwHmwIFXbcOWxMA3uDMXKNfnNzepaaI3mkrN4fUSM9rw:1wVsNr:0Do8Km9h8LeUKGLmCoeFVR4DTaS2Bcn6ab-d_-HGGVk	2026-06-07 11:52:23.904101-03
z52r4jyc1g1yp70vecyao9ajswd5981n	.eJxVjcsOwiAURP-FddNQ7gWKS_d-A-Fp8QFNaRON8d9tTRe6nTlz5kW0WeZBLzVMOnlyIECa38wadw15K_zF5HNpXcnzlGy7Ie3e1vZUfLgdd_ZPMJg6rGtJFQIgOAGCo6IQuewg8B6ZcJxJVJEyCxGE6jlnMVhkjoXOKxSGKrlJa6g1lazDY0zTkxx6gZQ25Hszp7GsN8bfUybvDyhTROg:1wDkGU:MYEp-2V1sRD86hG_CFOiru6lf41-94m7k0A7UhE6RRE	2026-04-18 11:33:50.749256-03
y0bjoltrduuhsfjk3k2ymlywaf0gmlpm	.eJxVjcsOwiAURP-FddNQ7gWKS_d-A-Fp8QFNaRON8d9tTRe6nTlz5kW0WeZBLzVMOnlyIECa38wadw15K_zF5HNpXcnzlGy7Ie3e1vZUfLgdd_ZPMJg6rGtJFQIgOAGCo6IQuewg8B6ZcJxJVJEyCxGE6jlnMVhkjoXOKxSGKrlJa6g1lazDY0zTkxx6gZQ25Hszp7GsN8bfUybvDyhTROg:1vf9Ox:BO9q9GpKX7Gvrrnk3aUie5PyOmnVPDHZaKEluuxuv80	2026-01-13 01:19:35.476919-03
52g0rhdkwmz1oje5bmjwckdfyyf1eh0t	.eJxVjcsOwiAURP-FddNQ7gWKS_d-A-Fp8QFNaRON8d9tTRe6nTlz5kW0WeZBLzVMOnlyIECa38wadw15K_zF5HNpXcnzlGy7Ie3e1vZUfLgdd_ZPMJg6rGtJFQIgOAGCo6IQuewg8B6ZcJxJVJEyCxGE6jlnMVhkjoXOKxSGKrlJa6g1lazDY0zTkxx6gZQ25Hszp7GsN8bfUybvDyhTROg:1vguqn:0FzCnv1dgLeLmLMtBGVRKXohJZiwWfNF5A-y7nIS3TE	2026-01-17 22:11:37.962019-03
nmnqikj0na6iv1nvkdanmkfzb3kmlrbm	.eJxVjcsOwiAURP-FddNQ7gWKS_d-A-Fp8QFNaRON8d9tTRe6nTlz5kW0WeZBLzVMOnlyIECa38wadw15K_zF5HNpXcnzlGy7Ie3e1vZUfLgdd_ZPMJg6rGtJFQIgOAGCo6IQuewg8B6ZcJxJVJEyCxGE6jlnMVhkjoXOKxSGKrlJa6g1lazDY0zTkxx6gZQ25Hszp7GsN8bfUybvDyhTROg:1vhVRD:1NsLCPSI7PLMSQatJ0MOUuaNNLiw9vHpSTNmuAgVhPo	2026-01-19 13:15:39.089547-03
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_site (id, domain, name) FROM stdin;
1	example.com	example.com
\.


--
-- Data for Name: historico_mensagem_automatica; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.historico_mensagem_automatica (id, data_tentativa, status, detalhes, mensagem_final_enviada, api_message_id, data_envio, cliente_id, mensagem_configurada_id) FROM stdin;
1	2026-06-04 19:45:13.487342-03	ENVIADO	Código verificação WhatsApp: 875933	🔐 *CÓDIGO DE VERIFICAÇÃO*\n\nOlá! Seu código de verificação é:\n\n*875933*\n\n⚠️ Não compartilhe este código com ninguém.\n⏰ Este código expira em 5 minutos.\n\nSe você não solicitou este código, ignore esta mensagem.	\N	2026-06-04 19:45:13.487342-03	\N	\N
\.


--
-- Data for Name: whatsapp_integration_historicoenviomassa; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.whatsapp_integration_historicoenviomassa (id, status, data_envio, cliente_id, mensagem_massa_id, data_confirmacao, mensagem_erro, message_id, whatsapp) FROM stdin;
\.


--
-- Data for Name: whatsapp_integration_mensagemmassa; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.whatsapp_integration_mensagemmassa (id, mensagem, data_agendamento, remetente_id, agendada, data_criacao, data_envio_fim, enviados_com_falha, enviados_com_sucesso, status, data_envio_inicio, dias_vencido_filtro, midia, plano_filtro_id, status_filtro, tipo_midia, total_destinatarios) FROM stdin;
\.


--
-- Data for Name: whatsapp_integration_mensagemmassa_tags_filtro; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.whatsapp_integration_mensagemmassa_tags_filtro (id, mensagemmassa_id, tag_id) FROM stdin;
\.


--
-- Data for Name: whatsapp_integration_userinstance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.whatsapp_integration_userinstance (id, instance_name, status, user_id, created_at, last_check, owner_jid, profile_name, profile_pic_url, instance_token, is_active, qr_code_data, qr_generated_at, api_key, base_url) FROM stdin;
2	teste_pc	connected	3	2026-06-04 19:09:34.410169-03	2026-06-04 19:09:50.588462-03	556481688931@s.whatsapp.net	Tiago	https://pps.whatsapp.net/v/t61.24694-24/604013595_1524881422075346_2735566125605828191_n.jpg?ccb=11-4&oh=01_Q5Aa4wGWcu50_oK_2JVjtv7amKBpu0xlhFIsmVnZkUoLftK5VA&oe=6A2F075B&_nc_sid=5e03e0&_nc_cat=106	\N	t	data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAVwAAAFcCAYAAACEFgYsAAAjCklEQVR4AezB0Y1kya5swTUbJQX1oi4uAnWhXq5Gv/l7/AogkFm75+DS7J8//2Kttdave1hrrfWKh7XWWq94WGut9YqHtdZar3hYa631ioe11lqveFhrrfWKh7XWWq94WGut9YqHtdZar3hYa631ih8uRSVvsppviko+YTVTVDJZzRSVfMJqpqjkxGpOopLJaqao5BNWM0UlJ1YzRSVvspopKpms5kZU8gmrmaKSyWqmqGSymikq+YTVTFHJidVMUckNq/lEVPImq7nxsNZa6xUPa621XvGw1lrrFT98yGq+KSo5iUpOrGaKSiarmaKSE6s5sZopKrlhNW+ymhOrmaKSyWqmqOSG1XyT1ZxEJSdRyWQ1J1HJZDWT1ZxEJSdRyWQ1U1TyCauZopLJaqaoZLKaKSqZopLJam5EJTes5sRqvikq+cTDWmutVzystdZ6xcNaa61X/PBlUckNq/mE1UxRyQ2ruRGVfMJqpqhkspoTq5mikikquWE1U1TyTVZzw2qmqGSymhtWcyMqObGaKSq5YTU3opITqzmxmhOr+YTVTFHJFJVMVnPDaqao5BNRyQ2r+aaHtdZar3hYa631ioe11lqv+OF/XFRyYjUnUcmJ1ZxYzRSVTFZzYjUnUclkNZPVTFHJidVMUcmNqOQkKvmE1fymqOTEam5YzY2oZLKaE6uZopKTqGSymikqObGab7Ka9f89rLXWesXDWmutVzystdZ6xQ//46xmikpOopLJak6ikk9EJZPVnEQlk9VMUcknopITq5mikjdFJTeikslqflNU8k1RySeikpOoZLKaKSqZopLJak6ikslqpqjkhtWcWM3/soe11lqveFhrrfWKh7XWWq/44cus5k1RyQ2ruWE1vykqmazmhtXciEomq7lhNVNUcsNqpqhksppPRCWT1UxW801WcyMqObGaT0Qlk9WcWM0UlUxRyTdZzRSVnEQlk9V8wmr+poe11lqveFhrrfWKh7XWWq/44UNRyd9kNVNUchKVTFYzRSWT1UxRyWQ1J1YzRSWT1UxRyWQ1N6KSyWpuRCWT1UxRyWQ1U1QyWc0UlUxWM0Ulk9VMUclkNVNUchKVTFYzRSWT1dyISiarObGaKSqZrGaKSiaruRGVTFZzYjVTVDJZzRSVTFYzRSWT1UxRyWQ1U1QyWc1JVPJf8rDWWusVD2uttV7xsNZa6xU/XLKav8lqTqzmRlQyWc2J1UxRyWQ1J1YzRSUnUckNq/mE1ZxYzRSVnEQlk9VMUclkNSdWcyMqmaxmikomq5mikhtW8zdZzTdFJZPVTFHJJ6KSG1ZzYjX/ZQ9rrbVe8bDWWusVD2uttV7xz59/8UVRyWQ1J1HJN1nNSVQyWc0UlZxYzSeikslqbkQlb7KaKSqZrGaKSiarOYlKTqxmikpOrGaKSk6s5iQq+S+xmikq+SarmaKSyWpOopITq5mikhtWM0Ulk9VMUck3Wc0nHtZaa73iYa211ise1lprveKHXxaVTFZzYjWfiEomq7lhNVNUMkUlJ1YzRSWT1UxRyWQ1U1TyTVZzEpXciEpOopLJar7JaqaoZLKaKSo5iUpOrGaKSiarOYlKJquZopIbVnMjKpms5sRqpqhksprJaqaoZIpKJquZopLJaqao5IbVTFHJZDVTVHISlUxWc+NhrbXWKx7WWmu94mGttdYrfrgUldywmikqmaxmikomq/lEVDJZzRSVnFjNm6KSyWpOopITq5mikhtRyYnV/E1RySeikv8yq3lTVHIjKpms5hNWc8NqpqjkE1YzRSXf9LDWWusVD2uttV7xsNZa6xU/fMhqpqjkxGqmqGSymikquWE1J1HJN0UlN6KSyWqmqOQkKvmE1dyISj4RlUxWc2I1J1YzRSUnUclkNVNU8iarmaKSk6jkb7KaKSqZrObEaqao5CQquRGVTFYzRSWT1dywmikq+cTDWmutVzystdZ6xcNaa61X/PChqGSympOoZLKaKSo5sZopKpmikslqPhGVTFZzYjVTVHLDaqaoZLKaKSqZrGaKSiarmaKSyWo+EZWcRCWT1ZxEJZ+wmikq+URUMlnNjajkE1YzRSXfZDVTVHISlUxWM0UlJ1HJZDVTVPIJq5mikslq3vSw1lrrFQ9rrbVe8bDWWusV//z5F18UlUxWcxKVTFZzEpVMVjNFJb/Jak6ikslqpqjkhtVMUclkNX9TVHJiNTeikslqpqhksppPRCWT1XwiKjmxmpOoZLKaKSqZrOZGVDJZzf+SqGSympOo5MRqbkQlk9XceFhrrfWKh7XWWq94WGut9YofLkUlJ1YzRSWT1ZxEJZPVnEQlk9VMUclkNVNUMlnNFJV8Iip5U1RyYjU3opLJaj4RlUxWc8NqpqhkspqTqORGVHJiNZPVnEQlJ1ZzIyqZrGaKSm5EJZPVnEQlk9WcRCUnVjNFJTeikk9EJZPVTFbziYe11lqveFhrrfWKh7XWWq/44cuikslqTqzmE1bzCas5sZopKpms5sRqpqjkxGpOrGaKSiarmaKSKSqZrOYTVjNFJZ+wmikqmazmRlTyCau5EZVMVjNZzUlU8jdZzUlUciMqObGaE6uZopJPWM0UlUxW85se1lprveJhrbXWKx7WWmu94ocPWc2NqGSymikqmazmRlQyWc0UlUxWcxKVTFZzYjU3rOYTVvNNUclkNVNUMlnNZDVTVHIjKpmsZopKbljNFJWcRCWT1ZxEJZPVnEQlk9VMVjNFJZPVnEQlJ1ZzIyqZrOYTVnMSlUxWcxKVTFYzRSUnVnMSlZxYzY2HtdZar3hYa631ioe11lqv+OfPv7gQldywmpOoZLKaKSqZrGaKSiar+URUMlnNSVQyWc0Ulfwmq5mikhtWcyMqmaxmikpOrOYTUckNq/mmqOSG1UxRyWQ1U1QyWc2NqGSymhtRyYnV/JdFJZPV3IhKJqv5poe11lqveFhrrfWKh7XWWq/44ZLV3IhKTqxmikomq/lEVDJZzYnVTFHJ32Q132Q1J1HJZDU3rGaKSn6T1UxRyRSVnFjNFJVMVnNiNSdRyWQ1U1QyWc1JVHJiNVNUMlnNidVMUcmNqOSG1UxRyYnV3IhKvikqmazmxsNaa61XPKy11nrFw1prrVf8cCkquWE1U1RyYjU3rGaKSiarmaKSyWqmqOTEam5YzY2o5EZUciMqObGaKSo5iUpOrOYkKjmxmslqbljNJ6KSyWqmqGSymslqfpPVnFjNFJV8IiqZrObEaqao5MRqbkQlJ1ZzEpVMVvObHtZaa73iYa211ise1lprveKHS1YzRSWT1XwiKrlhNTes5obVnEQlk9WcRCWT1dyISk6s5iQqOYlKvikqObGaG1HJZDWT1UxRyYnVTFYzRSWfiEomqzmJSk6s5iQq+U1Wc2I1U1QyWc3fFJWcRCUnVvOJh7XWWq94WGut9YqHtdZar/jnz7/4oqjkxGpuRCUnVnMSlZxYzUlUMlnNSVQyWc2NqGSympOo5MRqPhGVTFbzXxKVnFjNFJVMVjNFJZPVnEQln7CaKSqZrOZGVHJiNTeikhOrmaKSG1YzRSWT1ZxEJd9kNVNUMlnNJx7WWmu94mGttdYrHtZaa73inz//4ouikhtWM0Ulk9VMUckNq7kRlZxYzRSVTFbziajkxGqmqORvspopKjmxmikquWE1N6KSyWo+EZVMVjNFJSdWM0Ulk9WcRCUnVjNFJTesZopKbljNFJWcWM1JVDJZzRSVfMJqbkQlk9XceFhrrfWKh7XWWq94WGut9YofLkUlk9WcWM0UlUxRyWQ1J1YzRSU3opLJaiar+URUcsNqPmE1U1QyWc0UldywmikqmaKSE6uZopLJaqaoZLKaT1jNFJWcWM0nrGaKSk6s5r8kKvkmq5mikpOo5CQq+YTV3IhKvulhrbXWKx7WWmu94mGttdYr/vnzLz4QlUxWM0Ulv8lqpqjkm6xmikpOrGaKSm5YzRSV/E1WM0Ulk9VMUclkNVNUcmI1n4hKJquZopLJaqaoZLKaKSr5Jqs5iUomq5mikhtWM0Ulb7KaT0Ql32Q1J1HJZDWfeFhrrfWKh7XWWq94WGut9Yofviwqmaxmikomq7kRlUxRyWQ1J1HJZDU3rOYkKvlEVDJZzRSVTFZzIyqZrOa/LCqZrGaKSiarmaKSyWqmqOQTVnMjKjmJSk6ikslqpqhkspopKpmsZopKJqv5RFRyIyqZrObEam5EJVNUMlnNSVQyWc2Nh7XWWq94WGut9YqHtdZar/jhUlQyWc03RSWT1dyISiarmaxmikomq5mikhOr+SarmaKSG1HJZDWfiEo+EZVMVjNFJTeikpOoZLKaE6v5pqhkspqTqGSymm+KSj4RlZxYzRSVnEQlk9VMVjNFJTeikslqTqxmikomq5mikk88rLXWesXDWmutVzystdZ6xQ+XrGaKSr7Jav5LrOYTVnMSlZxYzRSVnFjNb7KaKSo5sZopKvmE1UxRySeikslqpqjkhtV8IiqZrGaKSiar+U1WM0UlU1TyX2I1N6KSyWqmqOSbHtZaa73iYa211ise1lprveKHD1nNjahkiko+YTVTVHISlXxTVHIjKrkRlZxEJd8UlXzCaqaoZLKak6jkhtWcRCUnVnNiNVNUMkUln7Cak6jkJCq5YTVTVDJZzRSVnFjNSVTym6KSb4pKftPDWmutVzystdZ6xcNaa61X/PPnX1yISiarmaKSG1bziahkspopKrlhNVNUMlnNFJVMVnMSldywmpOo5BNWcxKVnFjNFJV8wmpOopLJaqaoZLKak6hkspobUclkNVNUcmI1U1QyWc2NqOTEaj4RlZxYzUlUMlnNFJXcsJopKrlhNSdRyWQ1n3hYa631ioe11lqveFhrrfWKH77Maj4RldywmhtWcxKVTFZzYjUnUcmJ1UxRyRSVTFYzWc1JVPIJq5mikhOrOYlKbkQlk9VMUclkNVNUcmI1U1QyWc2NqOTEak6s5kZU8l8WlUxWM0Ulk9XciEomqzmJSk6ikslqpqhkspobD2uttV7xsNZa6xUPa621XvHDl0UlJ1ZzYjUnUclJVHISldyISk6sZopKTqxmikomq/lEVDJZzUlU8k1RyWQ1J1ZzIyo5iUpOrOZGVDJZzYnVTFHJFJVMVjNFJZPVTFHJZDVTVDJZzRSVnFjNFJV8wmqmqGSymt8UlZxEJZPVTFHJZDWfeFhrrfWKh7XWWq94WGut9Yp//vyL/5Co5IbVnEQlk9VMUcmJ1ZxEJZPVTFHJidWcRCWT1ZxEJZPVTFHJZDVTVHLDaj4RlZxYzUlUMlnNJ6KSG1YzRSUnVnMSldywmpOo5IbVTFHJZDVTVPJNVnMSldywmikqmaxmikpOrOYTD2uttV7xsNZa6xUPa621XvHDh6KSyWqmqGSymhOrmaKST1jNDauZopLJaiarmaKSE6s5iUomq5mikslq3mQ1U1QyWc0UlUxWM1nNFJXcsJqTqOSG1ZxEJVNUMlnNFJXcsJqTqOSG1fwmq/lNUcknopLJam5YzRSVTFZz42GttdYrHtZaa73iYa211it++LKo5EZUcmI1U1QyRSUnVnMjKjmJSiarObGaKSr5pqjkm6xmikqmqGSymikqOYlKJqv5pqhkspopKjmJSiarObGaKSo5iUomq5mikhOrmaKSyWpOopITq/mmqGSympOo5MRqpqhkspopKpmikhOrmaKSb3pYa631ioe11lqveFhrrfWKHy5FJb/Jar4pKrlhNVNUchKV/F9iNSdWM0Uln4hKTqxmspopKpmsZopKbljNFJWcWM0UlUxRySes5r/Maj5hNX+T1UxRySce1lprveJhrbXWKx7WWmu94ocvs5opKrkRlUxWc2I1J1HJidXcsJqTqGSKSk6s5obVnEQlU1QyWc0Ulfwmq5mikhOrOYlKpqjkxGpuWM0UlZxYzQ2rmaKST0Qlk9X8pqhkspopKjmxmikqmaxmikomq7lhNVNUMlnNmx7WWmu94mGttdYrHtZaa73ih0tWcxKVTFYzRSUnVjNFJZPVnEQlJ1Zzw2qmqGSymslqTqKSKSo5sZqTqOTEan5TVPKJqOTEar4pKjmJSk6sZopKTqxmikomqzmJSqaoZLKaKSq5YTU3rObEam5YzYnVTFHJZDVTVDJZzX/Jw1prrVc8rLXWesXDWmutV/zz51+8KCr5Jqu5EZVMVjNFJb/JaqaoZLKaKSo5sZopKrlhNVNUMlnNjajkhtWcRCWT1UxRyWQ1U1RyYjVTVDJZzTdFJZPV3IhKJqv5m6KSyWqmqGSymikqmazmRlQyWc0UlZxYzY2oZLKaGw9rrbVe8bDWWusVD2uttV7xw6WoZLKak6hksppPRCVTVHJiNSdRyQ2r+URUMlnNFJWcWM03RSU3opLJaiarOYlKbljNFJVMVnNiNVNUcmI1U1QyWc0UlUxWM0UlJ1HJJ6KSyWpOopLJam5EJZPVfFNUcmI13xSVTFbzmx7WWmu94mGttdYrHtZaa73ihw9FJSdWM0Ulk9VMUcknrGaKSk6sZopKJqu5EZVMVnMSlUxWcyMqmaxmikomq/mbrOYTVnMSlUxWcyMqmaxmikomq7lhNSdRySeikhOrmaKSyWqmqOQ3Wc0UlUxWM0UlJ1HJZDVTVDJZzZse1lprveJhrbXWKx7WWmu94odLVjNFJSdRyQ2ruRGVTFHJZDU3rGaKSiarmaKSyWpuWM1JVDJZzSeikslqbljNFJX8JquZopI3RSU3opJPWM0UlUxWcxKVnEQlk9VMUclkNVNU8jdZzUlUciMquWE1n3hYa631ioe11lqveFhrrfWKHy5FJSdWcyMqObGaKSr5RFTypqhksppvsppvikpOrObEaqao5MRqpqjkxGpOopITqzmxmpOo5IbV3IhKJqv5hNWcRCWT1UxRyWQ1N6zmJCqZrOYTVvNNVjNFJZPV3HhYa631ioe11lqveFhrrfWKHy5ZzRSVnEQlN6xmikomq5mikpOo5IbVnEQlJ1HJZDVTVHLDak6ikslqTqzmm6zmm6xmikpuWM0UlUxWM0Ulk9VMUclvikomq5mikhtWM0Ulk9VMVjNFJSdRyYnVTFHJidVMUcmJ1UxRyWQ1U1Ryw2qmqGSymk88rLXWesXDWmutVzystdZ6xQ+/zGqmqOQkKpmsZopKJqv5TVHJZDU3opLJaqaoZLKaKSqZrOaG1ZxEJSdWM0Ulk9V8Iio5sZpvikpOopLfFJWcRCWfiEpuRCWT1UxRyWQ1U1QyRSUnVjNFJSdWM0Ul32Q1U1QyWc03Pay11nrFw1prrVc8rLXWesU/f/7FhahkspqTqGSymikqmaxmikomq5mikslqTqKSG1YzRSWfsJopKjmxmikquWE1N6KSE6uZopLJaqaoZLKab4pKJqs5iUomq5mikt9kNSdRyQ2rOYlKJqu5EZVMVvObopITq5mikslqTqKSG1bzTQ9rrbVe8bDWWusVD2uttV7xw4eikslqJquZopKTqOQkKvkmq5mikhtW801WM0Ulk9VMUclJVHLDaj4RlZxEJTes5sRqTqKSyWo+YTUnUcknrGaKSiarmaKSyWomq5mikslqflNUcmI1J1YzRSU3opITq7kRlUxWc+NhrbXWKx7WWmu94mGttdYrfniZ1dyISm5EJSdWM0Ulk9WcWM1JVHLDaj5hNVNUcmI1J1HJN1nNFJXciEomq5mikslqJquZopLJak6s5obVnEQln4hKvikqObGaKSq5YTVTVDJFJSdRyWQ1U1RyYjVTVPI3Pay11nrFw1prrVc8rLXWesU/f/7FB6KSv8lqbkQl32Q1J1HJidXciEp+k9VMUcmJ1UxRyW+ymikqObGaKSqZrGaKSiarmaKSb7Kak6hkspopKpmsZopKJqs5iUpOrGaKSr7Jak6ikm+ympOoZLKaTzystdZ6xcNaa61XPKy11nrFP3/+xRdFJTes5kZUMlnNjahkspopKvmE1ZxEJZPV3IhKJqu5EZVMVnMSlUxWM0UlN6xmikomqzmJSm5YzUlU8gmruRGVnFjNFJWcWM0UlUxW801RyWQ1U1QyWc0UlUxWM0UlN6zmRlRyYjVTVHJiNTce1lprveJhrbXWKx7WWmu94odLUclkNZPVnEQlJ1HJZDU3opLJam5YzTdFJTeikslqbkQlk9XciEomq5mikslqTqKSKSqZrGaKSiarmaxmikomq/mbopLJar7Jam5EJZPVTFHJZDVTVDJZzRSVTFbzN0Ulk9X8lzystdZ6xcNaa61XPKy11nrFD5es5iQq+YTVvCkqmazmJCqZrOaG1UxRyWQ1n7Cab4pKJquZopJvspopKpmsZrKaKSqZrGaKSk6sZopKbljNb4pKbljNFJXcsJopKpmsZopKJqs5iUomq5mikhtW85us5hMPa621XvGw1lrrFQ9rrbVe8cOlqOTEak6ikikqeZPVTFHJN0Ul3xSVnEQlf5PV3IhKpqjkRlQyWc0NqzmJSiarmaKSKSr5hNVMUcmJ1UxRyWQ1U1RyYjUnUclkNVNUMlnNFJXciEpuRCXfFJVMVjNFJZPV3HhYa631ioe11lqveFhrrfWKHy5ZzTdZzUlUMlnNFJVMVvOJqGSymslqpqhkspqTqGSymhOruRGVTFZzEpVMVjNFJSdRyTdZzRSVTFYzRSU3opITq5mikm+ymhOrmaKSKSqZrGaKSk6s5pus5obVnEQln7CaKSqZrOYkKpmikslqPvGw1lrrFQ9rrbVe8bDWWusV//z5Fx+ISm5YzRSVfJPVfFNUMlnNjajkE1ZzIyo5sZqTqGSymikqObGak6hkspopKjmxmikq+YTVnEQln7Cak6hkspopKrlhNVNUMlnNSVRyYjU3opITqzmJSn6T1UxRyWQ1U1QyWc2Nh7XWWq94WGut9YqHtdZar/jnz7/4RVHJDau5EZXcsJopKpms5kZUcmI1U1RyYjUnUck3Wc1JVHJiNd8UlUxWM0Ulk9WcRCUnVnMSlUxWcxKVnFjNFJWcWM0UlUxWcxKVnFjNjajkxGqmqOTEaqao5MRqpqjkxGqmqOTEaqao5MRqbjystdZ6xcNaa61XPKy11nrFDx+KSj5hNVNUMlnNFJXcsJopKpmsZopKbljNSVRyIyo5sZqTqOTEaqao5IbVTFHJZDVTVDJZzRSVTFYzRSWT1dywmm+KSk6sZopKpqhkspopKpmikslqpqhksppPRCUnVvNNUclkNVNUMkUlk9VMUcmJ1fxND2uttV7xsNZa6xUPa621XvHPn39xISq5YTUnUclkNd8Uldywmikqmaxmiko+YTWfiEomqzmJSk6sZopKTqzmTVHJZDVTVHLDaqao5MRqpqjkm6xmikpOrGaKSiaruRGVTFbziajkxGpuRCWT1UxRyYnV/E0Pa621XvGw1lrrFQ9rrbVe8cMlqzmJSqaoZLKak6jkE1ZzYjVTVPIJqzmJSiarOYlKJquZopIbUcmNqORGVDJZzUlUcmI1U1Ryw2qmqGSymhOrOYlKJqv5pqhkspopKjmxmpOo5MRqpqjkxGp+U1QyWc0UlUxWM0UlN6KSyWqmqGSymhsPa621XvGw1lrrFQ9rrbVe8c+ff/EfFpVMVvOJqOTEaqaoZLKak6jkhtVMUcmJ1UxRyWQ1J1HJN1nNSVTyCat5U1RyYjUnUclkNVNUMlnNSVRyw2pOopLJak6ikhtWcxKVnFjNSVRyYjU3opLJan7Tw1prrVc8rLXWesXDWmutV/zwZVHJm6KSG1ZzEpXciEomq/mE1ZxEJZPVnEQlk9V8Iio5iUomqzmJSk6ikhtWM0UlJ1bzTVYzRSXfZDVTVHISlUxWM0Uln7Cak6jkxGpOopITq5mikhtWcxKVnFjNjYe11lqveFhrrfWKh7XWWq/458+/uBCVfMJqbkQl32Q1J1HJJ6zmJCo5sZopKpmsZopKJqv5pqjkE1YzRSWT1ZxEJSdWM0Ulk9VMUcmJ1bwpKjmxmk9EJZPVnEQlJ1ZzEpVMVnMSlUxWcxKVTFZzEpVMVnMSldywmhsPa621XvGw1lrrFQ9rrbVe8cOHrOZGVHLDam5EJb/JaqaoZIpKTqxmikpOrOYTUcmJ1ZxYzSeikslqTqKSyWqmqOQTVjNFJSdRyWQ1U1RyYjU3rOYkKjmxmslqTqKST0Qlk9V8U1RyIyqZrGaKSiaredPDWmutVzystdZ6xcNaa61X/HDJaqaoZLKaT1jNFJXcsJqTqGSymhOr+YTV3IhKTqxmspopKjmxmpOoZLKaKSr5RFQyWc1kNTeikpOo5MRqpqjkhtV8U1RyYjVTVHISlUxWM1nNFJWcRCWT1ZxEJZPV3LCaG1bzCas5iUo+8bDWWusVD2uttV7xsNZa6xX//PkXH4hKPmE1U1TyCau5EZVMVnMSlUxWcyMqObGaG1HJZDUnUcknrGaKSiaruRGVTFYzRSU3rOYkKrlhNVNUcsNqTqKSyWqmqOQ3Wc1JVDJZzY2o5IbVTFHJZDUnUckNqzmJSiar+cTDWmutVzystdZ6xcNaa61X/PDLrOYkKpms5iQq+S+JSiarmaKST0Qlk9V8wmqmqOTEaqao5CQqmazmRlQyWc0UlUxWc8NqbkQlN6xmikpOrGaKSk6s5iQqObGaN1nNjahkspopKpmsZrKaKSqZrGaKSk6s5pse1lprveJhrbXWKx7WWmu94ocPWc0UlXwiKpmsZrKak6jkxGomq5mikhtWM0UlJ1YzRSU3opLJak6ikhOrOYlKJqs5iUqmqOTEaqao5MRqTqKSyWqmqOTEaiarmaKSyWqmqORGVDJZzUlUcmI1U1RyIyq5EZVMVjNFJTesZopKPmE1U1QyWc0UlZxEJZPV3HhYa631ioe11lqveFhrrfWKHz4UlUxWcxKVTFbzm6zmhtV8wmqmqORGVPKJqGSymikqOYlKJqs5iUpOrOYkKpms5puikslqbkQlN6zmRlTyCauZopKTqOSG1dyISm5YzRSVTFYzRSVTVHJiNTesZopKJqv5xMNaa61XPKy11nrFw1prrVf8cCkquRGVTFZzEpV8wmqmqGSymikqObGaT1jNFJVMVnMSldywmikq+URUMlnNZDUnUclkNZPVnEQlN6xmikqmqOTEam5EJZPVnEQlk9VMUclkNSdRyQ2rOYlKpqhkspoTq5mikslqvslqpqjkxGpuWM03Pay11nrFw1prrVc8rLXWesU/f/7FF0UlN6zmRlRyw2pOopITq5mikslqpqhkspopKjmxmikquWE1U1QyWc0UlUxWM0UlJ1YzRSUnVnMSlUxW84mo5IbVTFHJZDXfFJV8wmqmqGSymjdFJZPV3IhKPmE1U1QyWc0nopLJam48rLXWesXDWmutVzystdZ6xQ8fikpuWM1JVHLDaqao5CQquRGVvCkqObGaKSo5sZoTqzmxmikqObGak6jkxGr+S6xmikpOrGaKSm5YzUlU8omoZLKaKSo5sZobUclkNZ+wmhtWcxKVnFjNNz2stdZ6xcNaa61XPKy11nrFD19mNTeikslq3mQ1J1HJDav5TVHJSVTyTVZzEpWcWM1kNVNUMkUlJ1YzRSWT1UxWM0UlN6KSyWpuWM0UldyISiaruRGVTFbzTVHJZDVTVDJFJZPVnFjNjahkspobVjNFJd/0sNZa6xUPa621XvGw1lrrFT98WVRyYjWT1UxRyQ2rmaxmikr+pqjkxGpuRCXfZDVTVHJiNVNUchKVnFjNSVTyTVYzRSVTVDJZzRSV/Kao5CQqmaxmspopKvlNVnPDak6sZopKPhGVfMJqvulhrbXWKx7WWmu94mGttdYrfviQ1XyT1ZxEJTesZopKpqhkspoTq/mE1XyT1dyISk6s5iQqObGaG1HJidWcWM1JVDJZzY2o5MRqbkQlN6xmikpOopLJaqaoZLKayWqmqORGVPJNVjNFJZPV3IhK/qaHtdZar3hY6/9GpJb5AAADlUlEQVS1Bwc3kCQhFAXflNoK/MIXTMAX/MKN2T1yQkpVd0q7+hEicsWDiIhc8eGQpXNTR7GxdDYdxaajmCydjaUzdRSbjmJj6Ww6ihOWztRRbCydqaOYLJ2po5gsncnSeaOjOGHpTB3FxtKZOoqNpXPC0pk6ik1HMVk6k6WzsXSmjuImS2fqKCZLZ2PpTB3FG5bO1FF8k6UzdRQnHkRE5IoHERG54kFERK748FJH8U2WzomOYrJ0JktnY+m8YelsOoo3LJ0THcWJjmLTUWw6isnSOdFR/FJHMVk6G0tn6igmS2fTUZywdKaOYmPpTB3FxtLZWDqbjmKydDaWztRRTJbOCUvnREdxoqPYWDrf9CAiIlc8iIjIFQ8iInLFhy+zdE50FCc6isnSmTqKydKZOoo3LJ2po/iljmKydCZL55csnW/qKDaWzhuWzqajmCydqaOYLJ2NpfNGR7GxdKaO4o2OYmPpTJbOG5bOpqN4w9K5qaN440FERK54EBGRKx5EROSKD/8zls7UUbxh6UwdxWTpTB3FZOlMHcWmo9h0FJOlM3UUb1g6U0dxwtKZOorJ0vmljuJER/FGR7GxdDaWztRRTB3FZOlMHcVk6fxSR3FTR7GxdDYdxWTpTJbO1FFMHcU3PYiIyBUPIiJyxYOIiFzx4T/G0pk6io2lM3UUk6UzdRRTR3HC0tlYOt/UUZywdKaO4oSlM3UUJzqKE5bO1FH8kqUzdRQbS2fTUZywdKaOYuooNh3FZOlMls7UUWw6ihOWzomO4oSl800dxWTpnOgoTjyIiMgVDyIicsWDiIhc8eHLOopf6igmS2fqKDaWztRRTJbO1FFMls6mo9hYOlNHccLSOdFRTB3FTZbOGx3FCUtn01G8YelMHcVk6UyWztRRbDqKydKZOoqNpTN1FJOlM1k6G0tn6ihOdBSTpTNZOpuOYtNRbCydjaUzdRS/9CAiIlc8iIjIFQ8iInLFn7//4oClc1NHsbF0Nh3FZOlMHcXG0pk6io2l80ZHMVk6v9RRTJbO1FFsLJ2po3jD0pk6isnSmTqKydKZOopvsnS+qaOYLJ0THcXG0tl0FJOls+koNpbOpqPYWDrf1FFMls6mo9hYOlNHceJBRESueBARkSseRETkij9//4WIiPzcg4iIXPEgIiJXPIiIyBUPIiJyxYOIiFzxICIiVzyIiMgVDyIicsWDiIhc8SAiIlc8iIjIFf8AnHiXEjhyAkcAAAAASUVORK5CYII=	2026-06-04 19:09:40.307238-03	\N	http://localhost:8080
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 132, true);


--
-- Name: clientes_atualizacao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_atualizacao_id_seq', 1, false);


--
-- Name: clientes_backuphistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_backuphistory_id_seq', 7, true);


--
-- Name: clientes_backupschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_backupschedule_id_seq', 1, true);


--
-- Name: clientes_configuracao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_configuracao_id_seq', 3, true);


--
-- Name: clientes_configuracaoindicacao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_configuracaoindicacao_id_seq', 3, true);


--
-- Name: clientes_configuracaomensagem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_configuracaomensagem_id_seq', 2, true);


--
-- Name: clientes_customuser_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_customuser_groups_id_seq', 1, false);


--
-- Name: clientes_customuser_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_customuser_id_seq', 13, true);


--
-- Name: clientes_customuser_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_customuser_tags_id_seq', 42, true);


--
-- Name: clientes_customuser_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_customuser_user_permissions_id_seq', 1, true);


--
-- Name: clientes_financialentry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_financialentry_id_seq', 30, true);


--
-- Name: clientes_financialscenario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_financialscenario_id_seq', 3, true);


--
-- Name: clientes_historicojogo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_historicojogo_id_seq', 1, false);


--
-- Name: clientes_historicomensagem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_historicomensagem_id_seq', 1, false);


--
-- Name: clientes_indicacao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_indicacao_id_seq', 17, true);


--
-- Name: clientes_jogofavorito_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_jogofavorito_id_seq', 1, false);


--
-- Name: clientes_logatividade_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_logatividade_id_seq', 88, true);


--
-- Name: clientes_mensagem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_mensagem_id_seq', 1, false);


--
-- Name: clientes_mensagemconfigurada_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_mensagemconfigurada_id_seq', 1, false);


--
-- Name: clientes_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_message_id_seq', 1, false);


--
-- Name: clientes_movimentacaocaixa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_movimentacaocaixa_id_seq', 1, false);


--
-- Name: clientes_relatoriofinanceiro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_relatoriofinanceiro_id_seq', 18, true);


--
-- Name: clientes_servico_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_servico_id_seq', 2, true);


--
-- Name: clientes_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_tag_id_seq', 35, true);


--
-- Name: clientes_tutorial_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_tutorial_id_seq', 1, false);


--
-- Name: clientes_verificationcode_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_verificationcode_id_seq', 27, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 4, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 33, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 106, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, true);


--
-- Name: historico_envio_massa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.historico_envio_massa_id_seq', 1, false);


--
-- Name: mensagem_massa_tags_filtro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mensagem_massa_tags_filtro_id_seq', 1, false);


--
-- Name: whatsapp_integration_historicomensagemautomatica_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.whatsapp_integration_historicomensagemautomatica_id_seq', 1, true);


--
-- Name: whatsapp_integration_mensagemmassa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.whatsapp_integration_mensagemmassa_id_seq', 1, false);


--
-- Name: whatsapp_integration_userinstance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.whatsapp_integration_userinstance_id_seq', 2, true);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: clientes_atualizacao clientes_atualizacao_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_atualizacao
    ADD CONSTRAINT clientes_atualizacao_pkey PRIMARY KEY (id);


--
-- Name: clientes_backuphistory clientes_backuphistory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_backuphistory
    ADD CONSTRAINT clientes_backuphistory_pkey PRIMARY KEY (id);


--
-- Name: clientes_backupschedule clientes_backupschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_backupschedule
    ADD CONSTRAINT clientes_backupschedule_pkey PRIMARY KEY (id);


--
-- Name: clientes_configuracao clientes_configuracao_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_configuracao
    ADD CONSTRAINT clientes_configuracao_pkey PRIMARY KEY (id);


--
-- Name: clientes_configuracaoindicacao clientes_configuracaoindicacao_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_configuracaoindicacao
    ADD CONSTRAINT clientes_configuracaoindicacao_pkey PRIMARY KEY (id);


--
-- Name: clientes_configuracaomensagem clientes_configuracaomensagem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_configuracaomensagem
    ADD CONSTRAINT clientes_configuracaomensagem_pkey PRIMARY KEY (id);


--
-- Name: clientes_configuracaomensagem clientes_configuracaomensagem_usuario_id_daa44fe9_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_configuracaomensagem
    ADD CONSTRAINT clientes_configuracaomensagem_usuario_id_daa44fe9_uniq UNIQUE (usuario_id);


--
-- Name: clientes_customuser_groups clientes_customuser_groups_customuser_id_group_id_1e46496d_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_customuser_groups
    ADD CONSTRAINT clientes_customuser_groups_customuser_id_group_id_1e46496d_uniq UNIQUE (customuser_id, group_id);


--
-- Name: clientes_customuser_groups clientes_customuser_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_customuser_groups
    ADD CONSTRAINT clientes_customuser_groups_pkey PRIMARY KEY (id);


--
-- Name: clientes_customuser clientes_customuser_link_acesso_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_customuser
    ADD CONSTRAINT clientes_customuser_link_acesso_key UNIQUE (link_acesso);


--
-- Name: clientes_customuser clientes_customuser_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_customuser
    ADD CONSTRAINT clientes_customuser_pkey PRIMARY KEY (id);


--
-- Name: clientes_customuser_tags clientes_customuser_tags_customuser_id_tag_id_4fadf8f8_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_customuser_tags
    ADD CONSTRAINT clientes_customuser_tags_customuser_id_tag_id_4fadf8f8_uniq UNIQUE (customuser_id, tag_id);


--
-- Name: clientes_customuser_tags clientes_customuser_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_customuser_tags
    ADD CONSTRAINT clientes_customuser_tags_pkey PRIMARY KEY (id);


--
-- Name: clientes_customuser_user_permissions clientes_customuser_user_customuser_id_permission_0ef42de2_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_customuser_user_permissions
    ADD CONSTRAINT clientes_customuser_user_customuser_id_permission_0ef42de2_uniq UNIQUE (customuser_id, permission_id);


--
-- Name: clientes_customuser_user_permissions clientes_customuser_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_customuser_user_permissions
    ADD CONSTRAINT clientes_customuser_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: clientes_customuser clientes_customuser_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_customuser
    ADD CONSTRAINT clientes_customuser_username_key UNIQUE (username);


--
-- Name: clientes_financialentry clientes_financialentry_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_financialentry
    ADD CONSTRAINT clientes_financialentry_pkey PRIMARY KEY (id);


--
-- Name: clientes_financialscenario clientes_financialscenario_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_financialscenario
    ADD CONSTRAINT clientes_financialscenario_pkey PRIMARY KEY (id);


--
-- Name: clientes_historicojogo clientes_historicojogo_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_historicojogo
    ADD CONSTRAINT clientes_historicojogo_pkey PRIMARY KEY (id);


--
-- Name: clientes_historicomensagem clientes_historicomensagem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_historicomensagem
    ADD CONSTRAINT clientes_historicomensagem_pkey PRIMARY KEY (id);


--
-- Name: clientes_indicacao clientes_indicacao_cliente_indicador_id_cli_5faabd0e_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_indicacao
    ADD CONSTRAINT clientes_indicacao_cliente_indicador_id_cli_5faabd0e_uniq UNIQUE (cliente_indicador_id, cliente_indicado_id);


--
-- Name: clientes_indicacao clientes_indicacao_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_indicacao
    ADD CONSTRAINT clientes_indicacao_pkey PRIMARY KEY (id);


--
-- Name: clientes_jogofavorito clientes_jogofavorito_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_jogofavorito
    ADD CONSTRAINT clientes_jogofavorito_pkey PRIMARY KEY (id);


--
-- Name: clientes_logatividade clientes_logatividade_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_logatividade
    ADD CONSTRAINT clientes_logatividade_pkey PRIMARY KEY (id);


--
-- Name: clientes_mensagem clientes_mensagem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_mensagem
    ADD CONSTRAINT clientes_mensagem_pkey PRIMARY KEY (id);


--
-- Name: clientes_mensagemconfigurada clientes_mensagemconfigurada_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_mensagemconfigurada
    ADD CONSTRAINT clientes_mensagemconfigurada_pkey PRIMARY KEY (id);


--
-- Name: clientes_message clientes_message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_message
    ADD CONSTRAINT clientes_message_pkey PRIMARY KEY (id);


--
-- Name: clientes_movimentacaocaixa clientes_movimentacaocaixa_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_movimentacaocaixa
    ADD CONSTRAINT clientes_movimentacaocaixa_pkey PRIMARY KEY (id);


--
-- Name: clientes_relatoriofinanceiro clientes_relatoriofinanceiro_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_relatoriofinanceiro
    ADD CONSTRAINT clientes_relatoriofinanceiro_pkey PRIMARY KEY (id);


--
-- Name: clientes_servico clientes_servico_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_servico
    ADD CONSTRAINT clientes_servico_pkey PRIMARY KEY (id);


--
-- Name: clientes_tag clientes_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_tag
    ADD CONSTRAINT clientes_tag_pkey PRIMARY KEY (id);


--
-- Name: clientes_tutorial clientes_tutorial_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_tutorial
    ADD CONSTRAINT clientes_tutorial_pkey PRIMARY KEY (id);


--
-- Name: clientes_verificationcode clientes_verificationcode_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_verificationcode
    ADD CONSTRAINT clientes_verificationcode_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: whatsapp_integration_historicoenviomassa historico_envio_massa_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_integration_historicoenviomassa
    ADD CONSTRAINT historico_envio_massa_pkey PRIMARY KEY (id);


--
-- Name: whatsapp_integration_mensagemmassa_tags_filtro mensagem_massa_tags_filtro_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_integration_mensagemmassa_tags_filtro
    ADD CONSTRAINT mensagem_massa_tags_filtro_pkey PRIMARY KEY (id);


--
-- Name: historico_mensagem_automatica whatsapp_integration_historicomensagemautomatica_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historico_mensagem_automatica
    ADD CONSTRAINT whatsapp_integration_historicomensagemautomatica_pkey PRIMARY KEY (id);


--
-- Name: whatsapp_integration_mensagemmassa_tags_filtro whatsapp_integration_men_mensagemmassa_id_tag_id_8206ad43_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_integration_mensagemmassa_tags_filtro
    ADD CONSTRAINT whatsapp_integration_men_mensagemmassa_id_tag_id_8206ad43_uniq UNIQUE (mensagemmassa_id, tag_id);


--
-- Name: whatsapp_integration_mensagemmassa whatsapp_integration_mensagemmassa_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_integration_mensagemmassa
    ADD CONSTRAINT whatsapp_integration_mensagemmassa_pkey PRIMARY KEY (id);


--
-- Name: whatsapp_integration_userinstance whatsapp_integration_userinstance_instance_name_df71448b_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_integration_userinstance
    ADD CONSTRAINT whatsapp_integration_userinstance_instance_name_df71448b_uniq UNIQUE (instance_name);


--
-- Name: whatsapp_integration_userinstance whatsapp_integration_userinstance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_integration_userinstance
    ADD CONSTRAINT whatsapp_integration_userinstance_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: clientes_backuphistory_usuario_id_f50c39db; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_backuphistory_usuario_id_f50c39db ON public.clientes_backuphistory USING btree (usuario_id);


--
-- Name: clientes_backupschedule_usuario_id_73bb758e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_backupschedule_usuario_id_73bb758e ON public.clientes_backupschedule USING btree (usuario_id);


--
-- Name: clientes_configuracao_usuario_id_a7858294; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_configuracao_usuario_id_a7858294 ON public.clientes_configuracao USING btree (usuario_id);


--
-- Name: clientes_configuracaoindicacao_cliente_id_d18b9af8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_configuracaoindicacao_cliente_id_d18b9af8 ON public.clientes_configuracaoindicacao USING btree (cliente_id);


--
-- Name: clientes_customuser_dono_id_7efa077d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_customuser_dono_id_7efa077d ON public.clientes_customuser USING btree (dono_id);


--
-- Name: clientes_customuser_groups_customuser_id_1e744e8e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_customuser_groups_customuser_id_1e744e8e ON public.clientes_customuser_groups USING btree (customuser_id);


--
-- Name: clientes_customuser_groups_group_id_fe22daaf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_customuser_groups_group_id_fe22daaf ON public.clientes_customuser_groups USING btree (group_id);


--
-- Name: clientes_customuser_plano_id_01a55938; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_customuser_plano_id_01a55938 ON public.clientes_customuser USING btree (plano_id);


--
-- Name: clientes_customuser_tags_customuser_id_b2867823; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_customuser_tags_customuser_id_b2867823 ON public.clientes_customuser_tags USING btree (customuser_id);


--
-- Name: clientes_customuser_tags_tag_id_359e053b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_customuser_tags_tag_id_359e053b ON public.clientes_customuser_tags USING btree (tag_id);


--
-- Name: clientes_customuser_user_permissions_customuser_id_6dfd210e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_customuser_user_permissions_customuser_id_6dfd210e ON public.clientes_customuser_user_permissions USING btree (customuser_id);


--
-- Name: clientes_customuser_user_permissions_permission_id_3c9a40cb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_customuser_user_permissions_permission_id_3c9a40cb ON public.clientes_customuser_user_permissions USING btree (permission_id);


--
-- Name: clientes_customuser_username_d4ac33d6_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_customuser_username_d4ac33d6_like ON public.clientes_customuser USING btree (username varchar_pattern_ops);


--
-- Name: clientes_financialentry_scenario_id_5964271b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_financialentry_scenario_id_5964271b ON public.clientes_financialentry USING btree (scenario_id);


--
-- Name: clientes_financialentry_user_id_d2b7c7c0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_financialentry_user_id_d2b7c7c0 ON public.clientes_financialentry USING btree (user_id);


--
-- Name: clientes_financialscenario_user_id_ca0c0119; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_financialscenario_user_id_ca0c0119 ON public.clientes_financialscenario USING btree (user_id);


--
-- Name: clientes_historicojogo_cliente_id_4d86bf4c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_historicojogo_cliente_id_4d86bf4c ON public.clientes_historicojogo USING btree (cliente_id);


--
-- Name: clientes_historicomensagem_cliente_id_4a13f5dc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_historicomensagem_cliente_id_4a13f5dc ON public.clientes_historicomensagem USING btree (cliente_id);


--
-- Name: clientes_historicomensagem_mensagem_configurada_id_7bf3422a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_historicomensagem_mensagem_configurada_id_7bf3422a ON public.clientes_historicomensagem USING btree (mensagem_configurada_id);


--
-- Name: clientes_indicacao_cliente_indicado_id_0844b064; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_indicacao_cliente_indicado_id_0844b064 ON public.clientes_indicacao USING btree (cliente_indicado_id);


--
-- Name: clientes_indicacao_cliente_indicador_id_63b2b5e9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_indicacao_cliente_indicador_id_63b2b5e9 ON public.clientes_indicacao USING btree (cliente_indicador_id);


--
-- Name: clientes_jogofavorito_cliente_id_25bdfaf7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_jogofavorito_cliente_id_25bdfaf7 ON public.clientes_jogofavorito USING btree (cliente_id);


--
-- Name: clientes_lo_tipo_ac_2c5f9d_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_lo_tipo_ac_2c5f9d_idx ON public.clientes_logatividade USING btree (tipo_acao, data_hora);


--
-- Name: clientes_lo_usuario_cfebf8_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_lo_usuario_cfebf8_idx ON public.clientes_logatividade USING btree (usuario_id, data_hora);


--
-- Name: clientes_logatividade_usuario_id_a51688a4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_logatividade_usuario_id_a51688a4 ON public.clientes_logatividade USING btree (usuario_id);


--
-- Name: clientes_mensagem_destinatario_id_ba06f84e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_mensagem_destinatario_id_ba06f84e ON public.clientes_mensagem USING btree (usuario_id);


--
-- Name: clientes_mensagemconfigurada_configuracao_id_a20c3332; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_mensagemconfigurada_configuracao_id_a20c3332 ON public.clientes_mensagemconfigurada USING btree (configuracao_id);


--
-- Name: clientes_message_receiver_id_f6201eaa; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_message_receiver_id_f6201eaa ON public.clientes_message USING btree (receiver_id);


--
-- Name: clientes_message_sender_id_79dae4af; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_message_sender_id_79dae4af ON public.clientes_message USING btree (sender_id);


--
-- Name: clientes_movimentacaocaixa_usuario_id_51e501f6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_movimentacaocaixa_usuario_id_51e501f6 ON public.clientes_movimentacaocaixa USING btree (usuario_id);


--
-- Name: clientes_relatoriofinanceiro_cliente_id_039114bb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_relatoriofinanceiro_cliente_id_039114bb ON public.clientes_relatoriofinanceiro USING btree (cliente_id);


--
-- Name: clientes_servico_revenda_id_b768b128; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_servico_revenda_id_b768b128 ON public.clientes_servico USING btree (revenda_id);


--
-- Name: clientes_tag_usuario_id_e422545e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX clientes_tag_usuario_id_e422545e ON public.clientes_tag USING btree (usuario_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: historico_envio_massa_cliente_id_e16bb49f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX historico_envio_massa_cliente_id_e16bb49f ON public.whatsapp_integration_historicoenviomassa USING btree (cliente_id);


--
-- Name: historico_envio_massa_mensagem_massa_id_96e6689d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX historico_envio_massa_mensagem_massa_id_96e6689d ON public.whatsapp_integration_historicoenviomassa USING btree (mensagem_massa_id);


--
-- Name: whatsapp_integration_histo_cliente_id_a3fd9d47; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX whatsapp_integration_histo_cliente_id_a3fd9d47 ON public.historico_mensagem_automatica USING btree (cliente_id);


--
-- Name: whatsapp_integration_histo_mensagem_configurada_id_f16f436d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX whatsapp_integration_histo_mensagem_configurada_id_f16f436d ON public.historico_mensagem_automatica USING btree (mensagem_configurada_id);


--
-- Name: whatsapp_integration_mensa_mensagemmassa_id_1c762193; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX whatsapp_integration_mensa_mensagemmassa_id_1c762193 ON public.whatsapp_integration_mensagemmassa_tags_filtro USING btree (mensagemmassa_id);


--
-- Name: whatsapp_integration_mensagemmassa_plano_filtro_id_ccf4626a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX whatsapp_integration_mensagemmassa_plano_filtro_id_ccf4626a ON public.whatsapp_integration_mensagemmassa USING btree (plano_filtro_id);


--
-- Name: whatsapp_integration_mensagemmassa_remetente_id_96d98cb7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX whatsapp_integration_mensagemmassa_remetente_id_96d98cb7 ON public.whatsapp_integration_mensagemmassa USING btree (remetente_id);


--
-- Name: whatsapp_integration_mensagemmassa_tags_filtro_tag_id_06189e57; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX whatsapp_integration_mensagemmassa_tags_filtro_tag_id_06189e57 ON public.whatsapp_integration_mensagemmassa_tags_filtro USING btree (tag_id);


--
-- Name: whatsapp_integration_userinstance_instance_name_df71448b_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX whatsapp_integration_userinstance_instance_name_df71448b_like ON public.whatsapp_integration_userinstance USING btree (instance_name varchar_pattern_ops);


--
-- Name: whatsapp_integration_userinstance_user_id_78f9fea9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX whatsapp_integration_userinstance_user_id_78f9fea9 ON public.whatsapp_integration_userinstance USING btree (user_id);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_backuphistory clientes_backuphisto_usuario_id_f50c39db_fk_clientes_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_backuphistory
    ADD CONSTRAINT clientes_backuphisto_usuario_id_f50c39db_fk_clientes_ FOREIGN KEY (usuario_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_backupschedule clientes_backupsched_usuario_id_73bb758e_fk_clientes_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_backupschedule
    ADD CONSTRAINT clientes_backupsched_usuario_id_73bb758e_fk_clientes_ FOREIGN KEY (usuario_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_configuracaoindicacao clientes_configuraca_cliente_id_d18b9af8_fk_clientes_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_configuracaoindicacao
    ADD CONSTRAINT clientes_configuraca_cliente_id_d18b9af8_fk_clientes_ FOREIGN KEY (cliente_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_configuracao clientes_configuracao_usuario_id_a7858294_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_configuracao
    ADD CONSTRAINT clientes_configuracao_usuario_id_a7858294_fk FOREIGN KEY (usuario_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_configuracaomensagem clientes_configuracaomensagem_usuario_id_daa44fe9_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_configuracaomensagem
    ADD CONSTRAINT clientes_configuracaomensagem_usuario_id_daa44fe9_fk FOREIGN KEY (usuario_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_customuser_user_permissions clientes_customuser__permission_id_3c9a40cb_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_customuser_user_permissions
    ADD CONSTRAINT clientes_customuser__permission_id_3c9a40cb_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_customuser clientes_customuser_dono_id_7efa077d_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_customuser
    ADD CONSTRAINT clientes_customuser_dono_id_7efa077d_fk FOREIGN KEY (dono_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_customuser_groups clientes_customuser_groups_customuser_id_1e744e8e_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_customuser_groups
    ADD CONSTRAINT clientes_customuser_groups_customuser_id_1e744e8e_fk FOREIGN KEY (customuser_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_customuser_groups clientes_customuser_groups_group_id_fe22daaf_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_customuser_groups
    ADD CONSTRAINT clientes_customuser_groups_group_id_fe22daaf_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_customuser clientes_customuser_plano_id_01a55938_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_customuser
    ADD CONSTRAINT clientes_customuser_plano_id_01a55938_fk FOREIGN KEY (plano_id) REFERENCES public.clientes_servico(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_customuser_tags clientes_customuser_tags_customuser_id_b2867823_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_customuser_tags
    ADD CONSTRAINT clientes_customuser_tags_customuser_id_b2867823_fk FOREIGN KEY (customuser_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_customuser_tags clientes_customuser_tags_tag_id_359e053b_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_customuser_tags
    ADD CONSTRAINT clientes_customuser_tags_tag_id_359e053b_fk FOREIGN KEY (tag_id) REFERENCES public.clientes_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_customuser_user_permissions clientes_customuser_user_permissions_customuser_id_6dfd210e_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_customuser_user_permissions
    ADD CONSTRAINT clientes_customuser_user_permissions_customuser_id_6dfd210e_fk FOREIGN KEY (customuser_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_financialentry clientes_financialentry_scenario_id_5964271b_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_financialentry
    ADD CONSTRAINT clientes_financialentry_scenario_id_5964271b_fk FOREIGN KEY (scenario_id) REFERENCES public.clientes_financialscenario(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_financialentry clientes_financialentry_user_id_d2b7c7c0_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_financialentry
    ADD CONSTRAINT clientes_financialentry_user_id_d2b7c7c0_fk FOREIGN KEY (user_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_financialscenario clientes_financialscenario_user_id_ca0c0119_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_financialscenario
    ADD CONSTRAINT clientes_financialscenario_user_id_ca0c0119_fk FOREIGN KEY (user_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_historicojogo clientes_historicojo_cliente_id_4d86bf4c_fk_clientes_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_historicojogo
    ADD CONSTRAINT clientes_historicojo_cliente_id_4d86bf4c_fk_clientes_ FOREIGN KEY (cliente_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_historicomensagem clientes_historicomensagem_cliente_id_4a13f5dc_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_historicomensagem
    ADD CONSTRAINT clientes_historicomensagem_cliente_id_4a13f5dc_fk FOREIGN KEY (cliente_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_historicomensagem clientes_historicomensagem_mensagem_configurada_id_7bf3422a_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_historicomensagem
    ADD CONSTRAINT clientes_historicomensagem_mensagem_configurada_id_7bf3422a_fk FOREIGN KEY (mensagem_configurada_id) REFERENCES public.clientes_mensagemconfigurada(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_indicacao clientes_indicacao_cliente_indicado_id_0844b064_fk_clientes_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_indicacao
    ADD CONSTRAINT clientes_indicacao_cliente_indicado_id_0844b064_fk_clientes_ FOREIGN KEY (cliente_indicado_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_indicacao clientes_indicacao_cliente_indicador_id_63b2b5e9_fk_clientes_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_indicacao
    ADD CONSTRAINT clientes_indicacao_cliente_indicador_id_63b2b5e9_fk_clientes_ FOREIGN KEY (cliente_indicador_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_jogofavorito clientes_jogofavorit_cliente_id_25bdfaf7_fk_clientes_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_jogofavorito
    ADD CONSTRAINT clientes_jogofavorit_cliente_id_25bdfaf7_fk_clientes_ FOREIGN KEY (cliente_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_logatividade clientes_logatividade_usuario_id_a51688a4_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_logatividade
    ADD CONSTRAINT clientes_logatividade_usuario_id_a51688a4_fk FOREIGN KEY (usuario_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_mensagem clientes_mensagem_usuario_id_66587a1f_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_mensagem
    ADD CONSTRAINT clientes_mensagem_usuario_id_66587a1f_fk FOREIGN KEY (usuario_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_mensagemconfigurada clientes_mensagemconfigurada_configuracao_id_a20c3332_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_mensagemconfigurada
    ADD CONSTRAINT clientes_mensagemconfigurada_configuracao_id_a20c3332_fk FOREIGN KEY (configuracao_id) REFERENCES public.clientes_configuracaomensagem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_message clientes_message_receiver_id_f6201eaa_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_message
    ADD CONSTRAINT clientes_message_receiver_id_f6201eaa_fk FOREIGN KEY (receiver_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_message clientes_message_sender_id_79dae4af_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_message
    ADD CONSTRAINT clientes_message_sender_id_79dae4af_fk FOREIGN KEY (sender_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_movimentacaocaixa clientes_movimentacaocaixa_usuario_id_51e501f6_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_movimentacaocaixa
    ADD CONSTRAINT clientes_movimentacaocaixa_usuario_id_51e501f6_fk FOREIGN KEY (usuario_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_relatoriofinanceiro clientes_relatoriofinanceiro_cliente_id_039114bb_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_relatoriofinanceiro
    ADD CONSTRAINT clientes_relatoriofinanceiro_cliente_id_039114bb_fk FOREIGN KEY (cliente_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_servico clientes_servico_revenda_id_b768b128_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_servico
    ADD CONSTRAINT clientes_servico_revenda_id_b768b128_fk FOREIGN KEY (revenda_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: clientes_tag clientes_tag_usuario_id_e422545e_fk_clientes_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes_tag
    ADD CONSTRAINT clientes_tag_usuario_id_e422545e_fk_clientes_customuser_id FOREIGN KEY (usuario_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk FOREIGN KEY (user_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: whatsapp_integration_historicoenviomassa historico_envio_mass_mensagem_massa_id_96e6689d_fk_mensagem_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_integration_historicoenviomassa
    ADD CONSTRAINT historico_envio_mass_mensagem_massa_id_96e6689d_fk_mensagem_ FOREIGN KEY (mensagem_massa_id) REFERENCES public.whatsapp_integration_mensagemmassa(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: historico_mensagem_automatica historico_mensagem_automa_mensagem_configurada_id_1f219f0f_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historico_mensagem_automatica
    ADD CONSTRAINT historico_mensagem_automa_mensagem_configurada_id_1f219f0f_fk FOREIGN KEY (mensagem_configurada_id) REFERENCES public.clientes_mensagemconfigurada(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: historico_mensagem_automatica historico_mensagem_automatica_cliente_id_d712a266_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historico_mensagem_automatica
    ADD CONSTRAINT historico_mensagem_automatica_cliente_id_d712a266_fk FOREIGN KEY (cliente_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: whatsapp_integration_historicoenviomassa whatsapp_integration_historicoenviomassa_cliente_id_605c6443_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_integration_historicoenviomassa
    ADD CONSTRAINT whatsapp_integration_historicoenviomassa_cliente_id_605c6443_fk FOREIGN KEY (cliente_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: whatsapp_integration_mensagemmassa_tags_filtro whatsapp_integration_mens_tag_id_06189e57_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_integration_mensagemmassa_tags_filtro
    ADD CONSTRAINT whatsapp_integration_mens_tag_id_06189e57_fk FOREIGN KEY (tag_id) REFERENCES public.clientes_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: whatsapp_integration_mensagemmassa_tags_filtro whatsapp_integration_mensagemmassa_id_1c762193_fk_whatsapp_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_integration_mensagemmassa_tags_filtro
    ADD CONSTRAINT whatsapp_integration_mensagemmassa_id_1c762193_fk_whatsapp_ FOREIGN KEY (mensagemmassa_id) REFERENCES public.whatsapp_integration_mensagemmassa(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: whatsapp_integration_mensagemmassa whatsapp_integration_mensagemmassa_plano_filtro_id_ccf4626a_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_integration_mensagemmassa
    ADD CONSTRAINT whatsapp_integration_mensagemmassa_plano_filtro_id_ccf4626a_fk FOREIGN KEY (plano_filtro_id) REFERENCES public.clientes_servico(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: whatsapp_integration_mensagemmassa whatsapp_integration_mensagemmassa_remetente_id_96d98cb7_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_integration_mensagemmassa
    ADD CONSTRAINT whatsapp_integration_mensagemmassa_remetente_id_96d98cb7_fk FOREIGN KEY (remetente_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: whatsapp_integration_userinstance whatsapp_integration_userinstance_user_id_78f9fea9_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_integration_userinstance
    ADD CONSTRAINT whatsapp_integration_userinstance_user_id_78f9fea9_fk FOREIGN KEY (user_id) REFERENCES public.clientes_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

\unrestrict YL5YZrdDHMRoZsYs1q0ce7Yx5K8wYuDJeR5RC7kZhWjRZuzvNQNPf8IJ81LZzTZ

